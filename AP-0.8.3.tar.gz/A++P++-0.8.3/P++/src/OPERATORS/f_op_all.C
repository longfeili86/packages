

#define COMPILE_SERIAL_APP

#include "A++.h"

extern "C"
   {
/* machine.h is found in MDI/machine.h through a link in A++/inc lude and P++/inc lude */
#include "machine.h"

   }

void Delete_SerialArray ( const intArray    & parallelArray, intSerialArray*    serialArray, const Array_Conformability_Info_Type *Temporary_Array_Set );
void Delete_SerialArray ( const floatArray  & parallelArray, floatSerialArray*  serialArray, const Array_Conformability_Info_Type *Temporary_Array_Set );
void Delete_SerialArray ( const doubleArray & parallelArray, doubleSerialArray* serialArray, const Array_Conformability_Info_Type *Temporary_Array_Set );











#define FLOATARRAY
floatSerialArray &
operator+ ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
        {
          printf ("\n\n\n### Inside of operator+ (floatSerialArray,floatSerialArray) for floatSerialArray class: (id=%d) = (id=%d) \n",
               Lhs.Array_ID(),Rhs.Array_ID());
        }

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator+");
     Rhs.Test_Consistency ("Test Rhs in operator+");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs.isTemporary() = %s \n",(Lhs.isTemporary()) ? "TRUE" : "FALSE");
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator+(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs.isTemporary() = %s \n",(Rhs.isTemporary()) ? "TRUE" : "FALSE");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator+(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;
     floatSerialArray* Rhs_SerialArray = NULL;

     intSerialArray* Mask_SerialArray = NULL;
     intSerialArray* Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ( (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
               (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) )
             {
               printf ("Sorry, not implemented: can't mix indirect addressing using where statements and two array (binary) operators!\n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
                  (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator+(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs_SerialArray->isTemporary() = %s \n",(Rhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & operator+(floatSerialArray,floatSerialArray)");
        }
#endif

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, *Lhs_SerialArray + *Rhs_SerialArray );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator 
	( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray + *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator+(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , Rhs , 
               MDI_f_Add_Array_Plus_Array,
               MDI_f_Add_Array_Plus_Array_Accumulate_To_Operand , floatSerialArray::Plus );
#endif
   }


floatSerialArray &
floatSerialArray::operator-- ()
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside floatSerialArray::operator-- () for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator-- -- Prefix operator");
#endif

     (*this) -= 1;
     return *this;
   }
 
floatSerialArray &
floatSerialArray::operator-- ( int x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside floatSerialArray::operator%s (int=%d) for floatSerialArray class! \n","--",x);

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator--(x=0) -- Postfix operator");
#endif

  // Postfix operator always passes zero as argument (strange but true -- See Stroustrup p594)
     APP_ASSERT( x == 0 );
     (*this) -= 1;
     return *this;
   }


#ifdef INTARRAY
/* There is no >>= operator and so the >> must be handled as a special case -- skip it for now */
floatSerialArray &
operator>> ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
        {
          printf ("\n\n\n### Inside of operator>> (floatSerialArray,floatSerialArray) for floatSerialArray class: (id=%d) = (id=%d) \n",
               Lhs.Array_ID(),Rhs.Array_ID());
        }

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator>>");
     Rhs.Test_Consistency ("Test Rhs in operator>>");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs.isTemporary() = %s \n",(Lhs.isTemporary()) ? "TRUE" : "FALSE");
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator>>(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs.isTemporary() = %s \n",(Rhs.isTemporary()) ? "TRUE" : "FALSE");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator>>(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;
     floatSerialArray* Rhs_SerialArray = NULL;

     intSerialArray* Mask_SerialArray = NULL;
     intSerialArray* Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ( (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
               (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) )
             {
               printf ("Sorry, not implemented: can't mix indirect addressing using where statements and two array (binary) operators!\n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
                  (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator>>(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs_SerialArray->isTemporary() = %s \n",(Rhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & operator>>(floatSerialArray,floatSerialArray)");
        }
#endif

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, *Lhs_SerialArray >> *Rhs_SerialArray );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator 
	( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray >> *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator>>(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , Rhs , 
               MDI_f_BIT_RSHIFT_Array_BitwiseRShift_Array,
               MDI_f_BIT_RSHIFT_Array_BitwiseRShift_Array_Accumulate_To_Operand , floatSerialArray::BitwiseRShift );
#endif
   }

floatSerialArray &
operator>> ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\n### Inside of operator>> (floatSerialArray,float) for floatSerialArray class: (id=%d) = scalar \n",Lhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator>>");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator>>(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
               APP_ASSERT(Lhs_SerialArray != NULL);
            // Lhs_SerialArray->displayReferenceCounts("AFTER PCE: *Lhs_SerialArray in floatSerialArray & operator>>(floatSerialArray,float)");
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator>>(floatSerialArray,float)");
        }
#endif

  // (11/27/2000) Added error checking (will not work with indirect addessing later!!!)
     APP_ASSERT(Temporary_Array_Set != NULL);

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator(Temporary_Array_Set,Lhs,Lhs_SerialArray,*Lhs_SerialArray >> x);
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in in floatSerialArray & operator>>(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x , 
               MDI_f_BIT_RSHIFT_Array_BitwiseRShift_Scalar,
               MDI_f_BIT_RSHIFT_Array_BitwiseRShift_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_BitwiseRShift );
#endif
   }

floatSerialArray &
operator>> ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator>> (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator>>");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator>>(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = 
	      floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL) Temporary_Array_Set =
	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x >> *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator>>(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Rhs , x , 
               MDI_f_BIT_RSHIFT_Scalar_BitwiseRShift_Array,
               MDI_f_BIT_RSHIFT_Scalar_BitwiseRShift_Array_Accumulate_To_Operand , floatSerialArray::Scalar_BitwiseRShift );
#endif
   }

#endif

#ifdef INTARRAY
floatSerialArray &
floatSerialArray::operator&= ( const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator&= (floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator&=");
     Rhs.Test_Consistency ("Test Rhs in floatSerialArray::operator&=");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator&=(floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & floatSerialArray::operator&=(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray  = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
	   puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
           APP_ABORT();
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
	       Rhs, Rhs_SerialArray );
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray  != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();
     bool rhsIsTemporary  = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary  == TRUE) || (rhsIsTemporary  == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, Rhs, This_SerialArray, Rhs_SerialArray, *This_SerialArray &= *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , Rhs ,
               MDI_f_BIT_AND_Array_BitwiseAND_Array_Accumulate_To_Operand , floatSerialArray::BitwiseAND_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator&=(floatSerialArray)");
        }
#endif

     return *this;
   }

#endif

#ifdef INTARRAY
floatSerialArray &
floatSerialArray::operator|= ( const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator|= (floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator|=");
     Rhs.Test_Consistency ("Test Rhs in floatSerialArray::operator|=");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator|=(floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & floatSerialArray::operator|=(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray  = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
	   puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
           APP_ABORT();
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
	       Rhs, Rhs_SerialArray );
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray  != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();
     bool rhsIsTemporary  = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary  == TRUE) || (rhsIsTemporary  == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, Rhs, This_SerialArray, Rhs_SerialArray, *This_SerialArray |= *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , Rhs ,
               MDI_f_BIT_OR_Array_BitwiseOR_Array_Accumulate_To_Operand , floatSerialArray::BitwiseOR_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator|=(floatSerialArray)");
        }
#endif

     return *this;
   }

#endif

#ifdef INTARRAY
floatSerialArray &
floatSerialArray::operator^= ( const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator^= (floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator^=");
     Rhs.Test_Consistency ("Test Rhs in floatSerialArray::operator^=");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator^=(floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & floatSerialArray::operator^=(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray  = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
	   puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
           APP_ABORT();
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
	       Rhs, Rhs_SerialArray );
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray  != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();
     bool rhsIsTemporary  = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary  == TRUE) || (rhsIsTemporary  == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, Rhs, This_SerialArray, Rhs_SerialArray, *This_SerialArray ^= *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , Rhs ,
               MDI_f_BIT_XOR_Array_BitwiseXOR_Array_Accumulate_To_Operand , floatSerialArray::BitwiseXOR_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator^=(floatSerialArray)");
        }
#endif

     return *this;
   }

#endif

intSerialArray &
floatSerialArray::convertTo_intArray () const
   {
// Used to implement the conversion functions between int float and double arrays

#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of convertTo_intArray for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operatorconvertTo_intArray");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in intSerialArray & floatSerialArray::convertTo_intArray()");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
	       Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( *this, This_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( *this, This_SerialArray);
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement (
                    *this, This_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask,
                    Mask_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	          ( *this, This_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask,
                    Mask_SerialArray);
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & floatSerialArray::convertTo_intArray () \n");
#endif
     intArray & Return_Value = floatArray::Abstract_int_Conversion_Operator ( Temporary_Array_Set, *this, This_SerialArray, This_SerialArray->convertTo_intArray() );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;


  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & floatSerialArray::convertTo_intArray()");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_int_Conversion_Operator ( *this ,
                   MDI_f_Array_convertTo_intArray_Array_Accumulate_To_Operand ,
                   floatSerialArray::convertTo_intArrayFunction );
#endif
   }

floatSerialArray &
floatSerialArray::convertTo_floatArray () const
   {
// Used to implement the conversion functions between int float and double arrays

#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of convertTo_floatArray for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operatorconvertTo_floatArray");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::convertTo_floatArray()");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
	       Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( *this, This_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( *this, This_SerialArray);
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement (
                    *this, This_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask,
                    Mask_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	          ( *this, This_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask,
                    Mask_SerialArray);
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & floatSerialArray::convertTo_floatArray () \n");
#endif
     floatArray & Return_Value = floatArray::Abstract_float_Conversion_Operator ( Temporary_Array_Set, *this, This_SerialArray, This_SerialArray->convertTo_floatArray() );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;


  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & floatSerialArray::convertTo_floatArray()");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_float_Conversion_Operator ( *this ,
                   MDI_f_Array_convertTo_floatArray_Array_Accumulate_To_Operand ,
                   floatSerialArray::convertTo_floatArrayFunction );
#endif
   }

doubleSerialArray &
floatSerialArray::convertTo_doubleArray () const
   {
// Used to implement the conversion functions between int float and double arrays

#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of convertTo_doubleArray for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operatorconvertTo_doubleArray");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in doubleSerialArray & floatSerialArray::convertTo_doubleArray()");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
	       Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( *this, This_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( *this, This_SerialArray);
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement (
                    *this, This_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask,
                    Mask_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	          ( *this, This_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask,
                    Mask_SerialArray);
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & floatSerialArray::convertTo_doubleArray () \n");
#endif
     doubleArray & Return_Value = floatArray::Abstract_double_Conversion_Operator ( Temporary_Array_Set, *this, This_SerialArray, This_SerialArray->convertTo_doubleArray() );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;


  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in doubleSerialArray & floatSerialArray::convertTo_doubleArray()");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_double_Conversion_Operator ( *this ,
                   MDI_f_Array_convertTo_doubleArray_Array_Accumulate_To_Operand ,
                   floatSerialArray::convertTo_doubleArrayFunction );
#endif
   }


floatSerialArray &
floatSerialArray::operator-= ( const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator-= (floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator-=");
     Rhs.Test_Consistency ("Test Rhs in floatSerialArray::operator-=");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator-=(floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & floatSerialArray::operator-=(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray  = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
	   puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
           APP_ABORT();
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
	       Rhs, Rhs_SerialArray );
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray  != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();
     bool rhsIsTemporary  = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary  == TRUE) || (rhsIsTemporary  == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, Rhs, This_SerialArray, Rhs_SerialArray, *This_SerialArray -= *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , Rhs ,
               MDI_f_Subtract_Array_Minus_Array_Accumulate_To_Operand , floatSerialArray::Minus_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator-=(floatSerialArray)");
        }
#endif

     return *this;
   }


floatSerialArray &
floatSerialArray::operator-= ( float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator-= (float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator-=");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator-=(float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( *this , This_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( *this , This_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, This_SerialArray, *This_SerialArray -= x );
     // ... don't need to use macro because Return_Value won't be Mask ...
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;

#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , x ,
        MDI_f_Subtract_Array_Minus_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_Minus_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator-=(float)");
        }
#endif

     return *this;
   }


floatSerialArray &
floatSerialArray::operator- () const
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of unary minus operator operator- for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operatoroperator-");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator-()");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( *this , This_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( *this , This_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, *this, This_SerialArray->operator-() );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = *this;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, *this, This_SerialArray, This_SerialArray->operator-() );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value (before delete This_SerialArray) in floatSerialArray & floatSerialArray::operator-()");
        }

  // This is the only test we can do on the output!
     Return_Value.Test_Consistency ("Test Return_Value (before delete This_SerialArray) in floatSerialArray::operatoroperator-");
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }

     // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & floatSerialArray::operator-()");
        }

  // This is the only test we can do on the output!
     Return_Value.Test_Consistency ("Test Return_Value in floatSerialArray::operatoroperator-");
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( *this ,
                   MDI_f_Unary_Minus_Array ,
                   MDI_f_Unary_Minus_Array_Accumulate_To_Operand , floatSerialArray::Unary_Minus );
#endif
   } 


floatSerialArray &
operator* ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
        {
          printf ("\n\n\n### Inside of operator* (floatSerialArray,floatSerialArray) for floatSerialArray class: (id=%d) = (id=%d) \n",
               Lhs.Array_ID(),Rhs.Array_ID());
        }

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator*");
     Rhs.Test_Consistency ("Test Rhs in operator*");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs.isTemporary() = %s \n",(Lhs.isTemporary()) ? "TRUE" : "FALSE");
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator*(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs.isTemporary() = %s \n",(Rhs.isTemporary()) ? "TRUE" : "FALSE");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator*(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;
     floatSerialArray* Rhs_SerialArray = NULL;

     intSerialArray* Mask_SerialArray = NULL;
     intSerialArray* Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ( (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
               (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) )
             {
               printf ("Sorry, not implemented: can't mix indirect addressing using where statements and two array (binary) operators!\n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
                  (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator*(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs_SerialArray->isTemporary() = %s \n",(Rhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & operator*(floatSerialArray,floatSerialArray)");
        }
#endif

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, *Lhs_SerialArray * *Rhs_SerialArray );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator 
	( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray * *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator*(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , Rhs , 
               MDI_f_Multiply_Array_Times_Array,
               MDI_f_Multiply_Array_Times_Array_Accumulate_To_Operand , floatSerialArray::Times );
#endif
   }


floatSerialArray &
operator* ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\n### Inside of operator* (floatSerialArray,float) for floatSerialArray class: (id=%d) = scalar \n",Lhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator*");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator*(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
               APP_ASSERT(Lhs_SerialArray != NULL);
            // Lhs_SerialArray->displayReferenceCounts("AFTER PCE: *Lhs_SerialArray in floatSerialArray & operator*(floatSerialArray,float)");
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator*(floatSerialArray,float)");
        }
#endif

  // (11/27/2000) Added error checking (will not work with indirect addessing later!!!)
     APP_ASSERT(Temporary_Array_Set != NULL);

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator(Temporary_Array_Set,Lhs,Lhs_SerialArray,*Lhs_SerialArray * x);
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in in floatSerialArray & operator*(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x , 
               MDI_f_Multiply_Array_Times_Scalar,
               MDI_f_Multiply_Array_Times_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_Times );
#endif
   }


floatSerialArray &
operator* ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator* (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator*");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator*(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = 
	      floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL) Temporary_Array_Set =
	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x * *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator*(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Rhs , x , 
               MDI_f_Multiply_Scalar_Times_Array,
               MDI_f_Multiply_Scalar_Times_Array_Accumulate_To_Operand , floatSerialArray::Scalar_Times );
#endif
   }


floatSerialArray &
floatSerialArray::operator*= ( const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator*= (floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator*=");
     Rhs.Test_Consistency ("Test Rhs in floatSerialArray::operator*=");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator*=(floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & floatSerialArray::operator*=(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray  = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
	   puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
           APP_ABORT();
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
	       Rhs, Rhs_SerialArray );
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray  != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();
     bool rhsIsTemporary  = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary  == TRUE) || (rhsIsTemporary  == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, Rhs, This_SerialArray, Rhs_SerialArray, *This_SerialArray *= *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , Rhs ,
               MDI_f_Multiply_Array_Times_Array_Accumulate_To_Operand , floatSerialArray::Times_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator*=(floatSerialArray)");
        }
#endif

     return *this;
   }


floatSerialArray &
floatSerialArray::operator*= ( float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator*= (float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator*=");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator*=(float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( *this , This_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( *this , This_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, This_SerialArray, *This_SerialArray *= x );
     // ... don't need to use macro because Return_Value won't be Mask ...
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;

#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , x ,
        MDI_f_Multiply_Array_Times_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_Times_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator*=(float)");
        }
#endif

     return *this;
   }


floatSerialArray &
operator/ ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator/ (floatSerialArray,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator/");
     Rhs.Test_Consistency ("Test Rhs in operator/");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator/(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator/(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;
     floatSerialArray* Rhs_SerialArray = NULL;

     intSerialArray* Mask_SerialArray = NULL;
     intSerialArray* Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
	   puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
           APP_ABORT();
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
	       Rhs, Rhs_SerialArray );
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, *Lhs_SerialArray / *Rhs_SerialArray );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator 
	( Temporary_Array_Set, Lhs, Rhs, 
	  Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray / *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator/(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Non_Commutative ( Lhs , Rhs , 
               MDI_f_Divide_Array_Divided_By_Array,
               MDI_f_Divide_Array_Divided_By_Array_Accumulate_To_Operand , floatSerialArray::Divided_By );
#endif
   }


floatSerialArray &
operator+ ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\n### Inside of operator+ (floatSerialArray,float) for floatSerialArray class: (id=%d) = scalar \n",Lhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator+");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator+(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
               APP_ASSERT(Lhs_SerialArray != NULL);
            // Lhs_SerialArray->displayReferenceCounts("AFTER PCE: *Lhs_SerialArray in floatSerialArray & operator+(floatSerialArray,float)");
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator+(floatSerialArray,float)");
        }
#endif

  // (11/27/2000) Added error checking (will not work with indirect addessing later!!!)
     APP_ASSERT(Temporary_Array_Set != NULL);

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator(Temporary_Array_Set,Lhs,Lhs_SerialArray,*Lhs_SerialArray + x);
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in in floatSerialArray & operator+(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x , 
               MDI_f_Add_Array_Plus_Scalar,
               MDI_f_Add_Array_Plus_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_Plus );
#endif
   }


floatSerialArray &
operator/ ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator/ (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator/");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator/(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = 
	      floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray     != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, *Lhs_SerialArray / x );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator/(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x , 
               MDI_f_Divide_Array_Divided_By_Scalar,
               MDI_f_Divide_Array_Divided_By_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_Divided_By );
#endif
   }


floatSerialArray &
operator/ ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of operator/ (float,floatSerialArray) for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator/");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator/(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Rhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = 
	      floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL) Temporary_Array_Set =
	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x / *Rhs_SerialArray );
  // return floatArray::Abstract_Binary_Operator ( Temporary_Array_Set, Rhs, x / *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator/(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Rhs , x , 
               MDI_f_Divide_Scalar_Divided_By_Array,
               MDI_f_Divide_Scalar_Divided_By_Array_Accumulate_To_Operand , floatSerialArray::Scalar_Divided_By );
#endif
   }


floatSerialArray &
floatSerialArray::operator/= ( const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator/= (floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator/=");
     Rhs.Test_Consistency ("Test Rhs in floatSerialArray::operator/=");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator/=(floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & floatSerialArray::operator/=(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray  = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
	   puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
           APP_ABORT();
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
	       Rhs, Rhs_SerialArray );
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray  != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();
     bool rhsIsTemporary  = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary  == TRUE) || (rhsIsTemporary  == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, Rhs, This_SerialArray, Rhs_SerialArray, *This_SerialArray /= *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , Rhs ,
               MDI_f_Divide_Array_Divided_By_Array_Accumulate_To_Operand , floatSerialArray::Divided_By_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator/=(floatSerialArray)");
        }
#endif

     return *this;
   }


floatSerialArray &
floatSerialArray::operator/= ( float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator/= (float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator/=");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator/=(float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( *this , This_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( *this , This_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, This_SerialArray, *This_SerialArray /= x );
     // ... don't need to use macro because Return_Value won't be Mask ...
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;

#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , x ,
        MDI_f_Divide_Array_Divided_By_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_Divided_By_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator/=(float)");
        }
#endif

     return *this;
   }


floatSerialArray &
operator% ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
        {
          printf ("\n\n\n### Inside of operator% (floatSerialArray,floatSerialArray) for floatSerialArray class: (id=%d) = (id=%d) \n",
               Lhs.Array_ID(),Rhs.Array_ID());
        }

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator%");
     Rhs.Test_Consistency ("Test Rhs in operator%");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs.isTemporary() = %s \n",(Lhs.isTemporary()) ? "TRUE" : "FALSE");
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator%(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs.isTemporary() = %s \n",(Rhs.isTemporary()) ? "TRUE" : "FALSE");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator%(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;
     floatSerialArray* Rhs_SerialArray = NULL;

     intSerialArray* Mask_SerialArray = NULL;
     intSerialArray* Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ( (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
               (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) )
             {
               printf ("Sorry, not implemented: can't mix indirect addressing using where statements and two array (binary) operators!\n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
                  (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator%(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs_SerialArray->isTemporary() = %s \n",(Rhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & operator%(floatSerialArray,floatSerialArray)");
        }
#endif

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, *Lhs_SerialArray % *Rhs_SerialArray );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator 
	( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray % *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator%(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , Rhs , 
               MDI_f_Fmod_Array_Modulo_Array,
               MDI_f_Fmod_Array_Modulo_Array_Accumulate_To_Operand , floatSerialArray::Modulo );
#endif
   }


floatSerialArray &
operator% ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\n### Inside of operator% (floatSerialArray,float) for floatSerialArray class: (id=%d) = scalar \n",Lhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator%");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator%(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
               APP_ASSERT(Lhs_SerialArray != NULL);
            // Lhs_SerialArray->displayReferenceCounts("AFTER PCE: *Lhs_SerialArray in floatSerialArray & operator%(floatSerialArray,float)");
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator%(floatSerialArray,float)");
        }
#endif

  // (11/27/2000) Added error checking (will not work with indirect addessing later!!!)
     APP_ASSERT(Temporary_Array_Set != NULL);

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator(Temporary_Array_Set,Lhs,Lhs_SerialArray,*Lhs_SerialArray % x);
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in in floatSerialArray & operator%(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x , 
               MDI_f_Fmod_Array_Modulo_Scalar,
               MDI_f_Fmod_Array_Modulo_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_Modulo );
#endif
   }


floatSerialArray &
operator% ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator% (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator%");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator%(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = 
	      floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL) Temporary_Array_Set =
	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x % *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator%(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Rhs , x , 
               MDI_f_Fmod_Scalar_Modulo_Array,
               MDI_f_Fmod_Scalar_Modulo_Array_Accumulate_To_Operand , floatSerialArray::Scalar_Modulo );
#endif
   }


floatSerialArray &
floatSerialArray::operator%= ( const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator%= (floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator%=");
     Rhs.Test_Consistency ("Test Rhs in floatSerialArray::operator%=");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator%=(floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & floatSerialArray::operator%=(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray  = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
	   puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
           APP_ABORT();
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
	       Rhs, Rhs_SerialArray );
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray  != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();
     bool rhsIsTemporary  = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary  == TRUE) || (rhsIsTemporary  == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, Rhs, This_SerialArray, Rhs_SerialArray, *This_SerialArray %= *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , Rhs ,
               MDI_f_Fmod_Array_Modulo_Array_Accumulate_To_Operand , floatSerialArray::Modulo_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator%=(floatSerialArray)");
        }
#endif

     return *this;
   }


floatSerialArray &
floatSerialArray::operator%= ( float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator%= (float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator%=");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator%=(float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( *this , This_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( *this , This_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, This_SerialArray, *This_SerialArray %= x );
     // ... don't need to use macro because Return_Value won't be Mask ...
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;

#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , x ,
        MDI_f_Fmod_Array_Modulo_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_Modulo_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator%=(float)");
        }
#endif

     return *this;
   }


#ifndef INTARRAY
floatSerialArray &
cos ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of cos for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in cos ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & cos(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, cos(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, cos(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & cos(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Cos_Array ,
                   MDI_f_Cos_Array_Accumulate_To_Operand , floatSerialArray::cos_Function );
#endif
   } 

#endif

floatSerialArray &
operator+ ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator+ (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator+");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator+(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = 
	      floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL) Temporary_Array_Set =
	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x + *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator+(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Rhs , x , 
               MDI_f_Add_Scalar_Plus_Array,
               MDI_f_Add_Scalar_Plus_Array_Accumulate_To_Operand , floatSerialArray::Scalar_Plus );
#endif
   }


#ifndef INTARRAY
floatSerialArray &
sin ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of sin for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in sin ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & sin(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, sin(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, sin(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & sin(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Sin_Array ,
                   MDI_f_Sin_Array_Accumulate_To_Operand , floatSerialArray::sin_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
tan ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of tan for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in tan ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & tan(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, tan(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, tan(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & tan(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Tan_Array ,
                   MDI_f_Tan_Array_Accumulate_To_Operand , floatSerialArray::tan_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
acos ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of acos for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in acos ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & acos(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, acos(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, acos(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & acos(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Arc_Cos_Array ,
                   MDI_f_Arc_Cos_Array_Accumulate_To_Operand , floatSerialArray::acos_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
asin ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of asin for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in asin ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & asin(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, asin(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, asin(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & asin(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Arc_Sin_Array ,
                   MDI_f_Arc_Sin_Array_Accumulate_To_Operand , floatSerialArray::asin_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
atan ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of atan for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in atan ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & atan(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, atan(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, atan(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & atan(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Arc_Tan_Array ,
                   MDI_f_Arc_Tan_Array_Accumulate_To_Operand , floatSerialArray::atan_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
cosh ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of cosh for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in cosh ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & cosh(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, cosh(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, cosh(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & cosh(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Cosh_Array ,
                   MDI_f_Cosh_Array_Accumulate_To_Operand , floatSerialArray::cosh_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
sinh ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of sinh for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in sinh ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & sinh(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, sinh(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, sinh(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & sinh(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Sinh_Array ,
                   MDI_f_Sinh_Array_Accumulate_To_Operand , floatSerialArray::sinh_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
tanh ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of tanh for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in tanh ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & tanh(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, tanh(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, tanh(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & tanh(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Tanh_Array ,
                   MDI_f_Tanh_Array_Accumulate_To_Operand , floatSerialArray::tanh_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
acosh ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of acosh for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in acosh ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & acosh(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, acosh(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, acosh(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & acosh(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Arc_Cosh_Array ,
                   MDI_f_Arc_Cosh_Array_Accumulate_To_Operand , floatSerialArray::acosh_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
asinh ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of asinh for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in asinh ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & asinh(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, asinh(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, asinh(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & asinh(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Arc_Sinh_Array ,
                   MDI_f_Arc_Sinh_Array_Accumulate_To_Operand , floatSerialArray::asinh_Function );
#endif
   } 

#endif

floatSerialArray &
floatSerialArray::operator++ ()
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside floatSerialArray::operator++ () for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator++ -- Prefix operator");
#endif

     (*this) += 1;
     return *this;
   }
 
floatSerialArray &
floatSerialArray::operator++ ( int x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside floatSerialArray::operator%s (int=%d) for floatSerialArray class! \n","++",x);

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator++(x=0) -- Postfix operator");
#endif

  // Postfix operator always passes zero as argument (strange but true -- See Stroustrup p594)
     APP_ASSERT( x == 0 );
     (*this) += 1;
     return *this;
   }


#ifndef INTARRAY
floatSerialArray &
atanh ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of atanh for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in atanh ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & atanh(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, atanh(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, atanh(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & atanh(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Arc_Tanh_Array ,
                   MDI_f_Arc_Tanh_Array_Accumulate_To_Operand , floatSerialArray::atanh_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
log ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of log for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in log ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & log(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, log(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, log(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & log(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Log_Array ,
                   MDI_f_Log_Array_Accumulate_To_Operand , floatSerialArray::log_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
log10 ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of log10 for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in log10 ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & log10(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, log10(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, log10(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & log10(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Log10_Array ,
                   MDI_f_Log10_Array_Accumulate_To_Operand , floatSerialArray::log10_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
exp ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of exp for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in exp ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & exp(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, exp(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, exp(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & exp(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Exp_Array ,
                   MDI_f_Exp_Array_Accumulate_To_Operand , floatSerialArray::exp_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
sqrt ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of sqrt for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in sqrt ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & sqrt(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, sqrt(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, sqrt(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & sqrt(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Sqrt_Array ,
                   MDI_f_Sqrt_Array_Accumulate_To_Operand , floatSerialArray::sqrt_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
fabs ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of fabs for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in fabs ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & fabs(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, fabs(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, fabs(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & fabs(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Fabs_Array ,
                   MDI_f_Fabs_Array_Accumulate_To_Operand , floatSerialArray::fabs_Function );
#endif
   } 

floatSerialArray &
abs ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of abs for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in abs ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & abs(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, abs(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, abs(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & abs(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Fabs_Array ,
                   MDI_f_Fabs_Array_Accumulate_To_Operand , floatSerialArray::abs_Function );
#endif
   } 

#else
floatSerialArray &
abs ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of abs for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in abs ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & abs(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, abs(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, abs(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & abs(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Abs_Array ,
                   MDI_f_Abs_Array_Accumulate_To_Operand , floatSerialArray::abs_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
ceil ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of ceil for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in ceil ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & ceil(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, ceil(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, ceil(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & ceil(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Ceil_Array ,
                   MDI_f_Ceil_Array_Accumulate_To_Operand , floatSerialArray::ceil_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
floor ( const floatSerialArray & X )
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of floor for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in floor ( const floatSerialArray & X )");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & floor(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (X, X_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, X, floor(*X_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = X;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, floor(*X_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & floor(floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X ,
                   MDI_f_Floor_Array ,
                   MDI_f_Floor_Array_Accumulate_To_Operand , floatSerialArray::floor_Function );
#endif
   } 

#endif

#ifndef INTARRAY
floatSerialArray &
floatSerialArray::replace ( const intSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::replace (intSerialArray,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::replace (intSerialArray,floatSerialArray)");
     Lhs.Test_Consistency ("Test Lhs in floatSerialArray::replace (intSerialArray,floatSerialArray)");
     Rhs.Test_Consistency ("Test Rhs in floatSerialArray::replace (intSerialArray,floatSerialArray)");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & floatSerialArray::replace(intSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & floatSerialArray::replace(intSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray  *This_SerialArray = NULL;
     intSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray  *Rhs_SerialArray = NULL;
     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	 (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
     {
	puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
        APP_ABORT();
     }
     else
     {
        Temporary_Array_Set = 
            floatSerialArray::Parallel_Conformability_Enforcement 
	       ( *this, This_SerialArray, Lhs, Lhs_SerialArray, 
	          Rhs  , Rhs_SerialArray );
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray    != NULL);
     APP_ASSERT(Lhs_SerialArray     != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();
     bool lhsIsTemporary  = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary  = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );
     APP_ASSERT ( (lhsIsTemporary == TRUE)  || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE)  || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, Lhs, Rhs,
               This_SerialArray, Lhs_SerialArray, Rhs_SerialArray,
               This_SerialArray->replace (*Lhs_SerialArray, *Rhs_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & floatSerialArray::replace(intSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Modification_Operator ( Lhs , Rhs , MDI_f_If_Array_Use_Array , floatSerialArray::replace_Function );
#endif
   }

#endif

#ifndef INTARRAY
floatSerialArray &
floatSerialArray::replace ( const intSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of floatSerialArray::replace (intSerialArray,x) for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::replace (intSerialArray,float)");
     Lhs.Test_Consistency ("Test Lhs in floatSerialArray::replace (intSerialArray,float)");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & floatSerialArray::replace(intSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray  *This_SerialArray = NULL;
     intSerialArray *Lhs_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	 (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
     {
        Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( *this, This_SerialArray, Lhs, Lhs_SerialArray );
     }
     else
     {
        Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( *this, This_SerialArray, Lhs, Lhs_SerialArray );
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray    != NULL);
     APP_ASSERT(Lhs_SerialArray     != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();
     bool lhsIsTemporary  = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );
     APP_ASSERT ( (lhsIsTemporary  == TRUE) || (lhsIsTemporary  == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in floatSerialArray & floatSerialArray::replace ( const intSerialArray & Lhs , float x )");
#endif
     floatArray & Return_Value = floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, Lhs,
               This_SerialArray, Lhs_SerialArray, This_SerialArray->replace (*Lhs_SerialArray, x) );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }

  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;


     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & floatSerialArray::replace(intSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Modification_Operator ( Lhs , x , MDI_f_If_Array_Use_Scalar , floatSerialArray::Scalar_replace_Function );
#endif
   }

#endif

floatSerialArray &
floatSerialArray::operator+= ( const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator+= (floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator+=");
     Rhs.Test_Consistency ("Test Rhs in floatSerialArray::operator+=");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator+=(floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & floatSerialArray::operator+=(floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray  = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      ( *this , This_SerialArray, Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
	   puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
           APP_ABORT();
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
	       Rhs, Rhs_SerialArray );
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray  != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();
     bool rhsIsTemporary  = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary  == TRUE) || (rhsIsTemporary  == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, Rhs, This_SerialArray, Rhs_SerialArray, *This_SerialArray += *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , Rhs ,
               MDI_f_Add_Array_Plus_Array_Accumulate_To_Operand , floatSerialArray::Plus_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator+=(floatSerialArray)");
        }
#endif

     return *this;
   }


#ifndef INTARRAY
floatSerialArray &
floatSerialArray::replace ( int x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of floatSerialArray::replace (x,floatSerialArray) for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::replace (int,floatSerialArray)");
     Rhs.Test_Consistency ("Test Rhs in floatSerialArray::replace (int,floatSerialArray)");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & floatSerialArray::replace(int,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray  = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement( *this, This_SerialArray, Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( *this, This_SerialArray, Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if ((Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
	   puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
           APP_ABORT();
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
	       Rhs, Rhs_SerialArray );
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = 
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray    != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();
     bool rhsIsTemporary  = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary  == TRUE) || (rhsIsTemporary  == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, Rhs,
               This_SerialArray, Rhs_SerialArray,
               This_SerialArray->replace (x, *Rhs_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & floatSerialArray::replace(int,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Modification_Operator ( Rhs , x , MDI_f_If_Scalar_Use_Array , Scalar_replace_Function );
#endif
   }

#endif

#ifndef INTARRAY
floatSerialArray &
fmod ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of fmod (floatSerialArray,floatSerialArray) for floatSerialArray class! Lhs:rc=%d Rhs:rc=%d ",
               Lhs.getRawDataReferenceCount(),Rhs.getRawDataReferenceCount());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in fmod");
     Rhs.Test_Consistency ("Test Rhs in fmod");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & fmod(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & fmod(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs and Rhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
	       puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
                     Rhs, Rhs_SerialArray );
             }

          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

  // New test (8/5/2000)
     APP_ASSERT(Temporary_Array_Set != NULL);
  // Temporary_Array_Set->display("Check to see what sort of communication model was used");

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & fmod(floatSerialArray,floatSerialArray)");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & fmod(floatSerialArray,floatSerialArray)");
        }
#endif

  // Inputs to floatArray::Abstract_Binary_Operator:
  //     1. Temporary_Array_Set is attached to the floatArray temporary returned by Abstract_Binary_Operator
  //     2. Lhs is used to get the Lhs partition information (PARTI parallel descriptor) and array reuse
  //     3. Rhs is used to get the Rhs partition information (PARTI parallel descriptor) in case the Lhs was 
  //        a NULL array (no data and no defined partitioning (i.e. no PARTI parallel descriptor)) and array reuse
  //     4. The floatSerialArray which is to be put into the floatArray temporary returned by Abstract_Binary_Operator
  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, fmod(*Lhs_SerialArray,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, fmod(*Lhs_SerialArray,*Rhs_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
  // if (Lhs_SerialArray != Return_Value.getSerialArrayPointer())
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & fmod(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator_Non_Commutative ( Lhs , Rhs , MDI_f_Fmod_Array_Modulo_Array, MDI_f_Fmod_Array_Modulo_Array_Accumulate_To_Operand , floatSerialArray::fmod_Function );
#endif
   }



floatSerialArray &
mod ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of mod (floatSerialArray,floatSerialArray) for floatSerialArray class! Lhs:rc=%d Rhs:rc=%d ",
               Lhs.getRawDataReferenceCount(),Rhs.getRawDataReferenceCount());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in mod");
     Rhs.Test_Consistency ("Test Rhs in mod");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & mod(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & mod(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs and Rhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
	       puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
                     Rhs, Rhs_SerialArray );
             }

          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

  // New test (8/5/2000)
     APP_ASSERT(Temporary_Array_Set != NULL);
  // Temporary_Array_Set->display("Check to see what sort of communication model was used");

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & mod(floatSerialArray,floatSerialArray)");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & mod(floatSerialArray,floatSerialArray)");
        }
#endif

  // Inputs to floatArray::Abstract_Binary_Operator:
  //     1. Temporary_Array_Set is attached to the floatArray temporary returned by Abstract_Binary_Operator
  //     2. Lhs is used to get the Lhs partition information (PARTI parallel descriptor) and array reuse
  //     3. Rhs is used to get the Rhs partition information (PARTI parallel descriptor) in case the Lhs was 
  //        a NULL array (no data and no defined partitioning (i.e. no PARTI parallel descriptor)) and array reuse
  //     4. The floatSerialArray which is to be put into the floatArray temporary returned by Abstract_Binary_Operator
  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, mod(*Lhs_SerialArray,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, mod(*Lhs_SerialArray,*Rhs_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
  // if (Lhs_SerialArray != Return_Value.getSerialArrayPointer())
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & mod(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator_Non_Commutative ( Lhs , Rhs , MDI_f_Fmod_Array_Modulo_Array, MDI_f_Fmod_Array_Modulo_Array_Accumulate_To_Operand , floatSerialArray::mod_Function );
#endif
   }



#else
floatSerialArray &
mod ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of mod (floatSerialArray,floatSerialArray) for floatSerialArray class! Lhs:rc=%d Rhs:rc=%d ",
               Lhs.getRawDataReferenceCount(),Rhs.getRawDataReferenceCount());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in mod");
     Rhs.Test_Consistency ("Test Rhs in mod");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & mod(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & mod(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs and Rhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
	       puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
                     Rhs, Rhs_SerialArray );
             }

          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

  // New test (8/5/2000)
     APP_ASSERT(Temporary_Array_Set != NULL);
  // Temporary_Array_Set->display("Check to see what sort of communication model was used");

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & mod(floatSerialArray,floatSerialArray)");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & mod(floatSerialArray,floatSerialArray)");
        }
#endif

  // Inputs to floatArray::Abstract_Binary_Operator:
  //     1. Temporary_Array_Set is attached to the floatArray temporary returned by Abstract_Binary_Operator
  //     2. Lhs is used to get the Lhs partition information (PARTI parallel descriptor) and array reuse
  //     3. Rhs is used to get the Rhs partition information (PARTI parallel descriptor) in case the Lhs was 
  //        a NULL array (no data and no defined partitioning (i.e. no PARTI parallel descriptor)) and array reuse
  //     4. The floatSerialArray which is to be put into the floatArray temporary returned by Abstract_Binary_Operator
  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, mod(*Lhs_SerialArray,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, mod(*Lhs_SerialArray,*Rhs_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
  // if (Lhs_SerialArray != Return_Value.getSerialArrayPointer())
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & mod(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator_Non_Commutative ( Lhs , Rhs , MDI_f_Fmod_Array_Modulo_Array, MDI_f_Fmod_Array_Modulo_Array_Accumulate_To_Operand , floatSerialArray::mod_Function );
#endif
   }



#endif

#ifndef INTARRAY
floatSerialArray &
fmod ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\nInside of fmod (float,floatSerialArray) for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in fmod");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & fmod(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
              (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}

        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & fmod(float,floatSerialArray)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, fmod(x,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, fmod(x,*Rhs_SerialArray) );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value (before delete macro) in floatSerialArray & fmod(float,floatSerialArray)");
        }
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & fmod(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator_Non_Commutative ( Rhs , x ,
               MDI_f_Fmod_Scalar_Modulo_Array,
               MDI_f_Fmod_Scalar_Modulo_Array_Accumulate_To_Operand , floatSerialArray::Scalar_fmod_Function );
#endif
   }



floatSerialArray &
mod ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\nInside of mod (float,floatSerialArray) for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in mod");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & mod(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
              (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}

        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & mod(float,floatSerialArray)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, mod(x,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, mod(x,*Rhs_SerialArray) );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value (before delete macro) in floatSerialArray & mod(float,floatSerialArray)");
        }
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & mod(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator_Non_Commutative ( Rhs , x ,
               MDI_f_Fmod_Scalar_Modulo_Array,
               MDI_f_Fmod_Scalar_Modulo_Array_Accumulate_To_Operand , floatSerialArray::Scalar_mod_Function );
#endif
   }



#else
floatSerialArray &
mod ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\nInside of mod (float,floatSerialArray) for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in mod");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & mod(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
              (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}

        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & mod(float,floatSerialArray)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, mod(x,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, mod(x,*Rhs_SerialArray) );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value (before delete macro) in floatSerialArray & mod(float,floatSerialArray)");
        }
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & mod(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator_Non_Commutative ( Rhs , x ,
               MDI_f_Fmod_Scalar_Modulo_Array,
               MDI_f_Fmod_Scalar_Modulo_Array_Accumulate_To_Operand , floatSerialArray::Scalar_mod_Function );
#endif
   }



#endif

#ifndef INTARRAY
floatSerialArray &
fmod ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of fmod (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in fmod");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts 
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & fmod(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & fmod(floatSerialArray,float)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, fmod(*Lhs_SerialArray,x) );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in floatSerialArray & fmod ( const floatSerialArray & Lhs , float x )");
#endif
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, fmod(*Lhs_SerialArray,x) );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & fmod(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x ,
               MDI_f_Fmod_Array_Modulo_Scalar,
               MDI_f_Fmod_Array_Modulo_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_fmod_Function );
#endif
   }

floatSerialArray &
mod ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of mod (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in mod");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts 
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & mod(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & mod(floatSerialArray,float)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, mod(*Lhs_SerialArray,x) );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in floatSerialArray & mod ( const floatSerialArray & Lhs , float x )");
#endif
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, mod(*Lhs_SerialArray,x) );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & mod(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x ,
               MDI_f_Fmod_Array_Modulo_Scalar,
               MDI_f_Fmod_Array_Modulo_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_mod_Function );
#endif
   }

#else
floatSerialArray &
mod ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of mod (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in mod");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts 
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & mod(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & mod(floatSerialArray,float)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, mod(*Lhs_SerialArray,x) );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in floatSerialArray & mod ( const floatSerialArray & Lhs , float x )");
#endif
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, mod(*Lhs_SerialArray,x) );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & mod(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x ,
               MDI_f_Fmod_Array_Modulo_Scalar,
               MDI_f_Fmod_Array_Modulo_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_mod_Function );
#endif
   }

#endif

floatSerialArray &
pow ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of pow (floatSerialArray,floatSerialArray) for floatSerialArray class! Lhs:rc=%d Rhs:rc=%d ",
               Lhs.getRawDataReferenceCount(),Rhs.getRawDataReferenceCount());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in pow");
     Rhs.Test_Consistency ("Test Rhs in pow");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & pow(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & pow(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs and Rhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
	       puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
                     Rhs, Rhs_SerialArray );
             }

          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

  // New test (8/5/2000)
     APP_ASSERT(Temporary_Array_Set != NULL);
  // Temporary_Array_Set->display("Check to see what sort of communication model was used");

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & pow(floatSerialArray,floatSerialArray)");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & pow(floatSerialArray,floatSerialArray)");
        }
#endif

  // Inputs to floatArray::Abstract_Binary_Operator:
  //     1. Temporary_Array_Set is attached to the floatArray temporary returned by Abstract_Binary_Operator
  //     2. Lhs is used to get the Lhs partition information (PARTI parallel descriptor) and array reuse
  //     3. Rhs is used to get the Rhs partition information (PARTI parallel descriptor) in case the Lhs was 
  //        a NULL array (no data and no defined partitioning (i.e. no PARTI parallel descriptor)) and array reuse
  //     4. The floatSerialArray which is to be put into the floatArray temporary returned by Abstract_Binary_Operator
  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, pow(*Lhs_SerialArray,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, pow(*Lhs_SerialArray,*Rhs_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
  // if (Lhs_SerialArray != Return_Value.getSerialArrayPointer())
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & pow(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator_Non_Commutative ( Lhs , Rhs , MDI_f_Pow_Array_Raised_To_Array, MDI_f_Pow_Array_Raised_To_Array_Accumulate_To_Operand , floatSerialArray::pow_Function );
#endif
   }




floatSerialArray &
pow ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\nInside of pow (float,floatSerialArray) for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in pow");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & pow(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
              (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}

        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & pow(float,floatSerialArray)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, pow(x,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, pow(x,*Rhs_SerialArray) );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value (before delete macro) in floatSerialArray & pow(float,floatSerialArray)");
        }
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & pow(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator_Non_Commutative ( Rhs , x ,
               MDI_f_Pow_Scalar_Raised_To_Array,
               MDI_f_Pow_Scalar_Raised_To_Array_Accumulate_To_Operand , floatSerialArray::Scalar_pow_Function );
#endif
   }




floatSerialArray &
pow ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of pow (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in pow");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts 
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & pow(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & pow(floatSerialArray,float)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, pow(*Lhs_SerialArray,x) );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in floatSerialArray & pow ( const floatSerialArray & Lhs , float x )");
#endif
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, pow(*Lhs_SerialArray,x) );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & pow(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x ,
               MDI_f_Pow_Array_Raised_To_Scalar,
               MDI_f_Pow_Array_Raised_To_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_pow_Function );
#endif
   }


floatSerialArray &
sign ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of sign (floatSerialArray,floatSerialArray) for floatSerialArray class! Lhs:rc=%d Rhs:rc=%d ",
               Lhs.getRawDataReferenceCount(),Rhs.getRawDataReferenceCount());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in sign");
     Rhs.Test_Consistency ("Test Rhs in sign");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & sign(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & sign(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs and Rhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
	       puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
                     Rhs, Rhs_SerialArray );
             }

          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

  // New test (8/5/2000)
     APP_ASSERT(Temporary_Array_Set != NULL);
  // Temporary_Array_Set->display("Check to see what sort of communication model was used");

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & sign(floatSerialArray,floatSerialArray)");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & sign(floatSerialArray,floatSerialArray)");
        }
#endif

  // Inputs to floatArray::Abstract_Binary_Operator:
  //     1. Temporary_Array_Set is attached to the floatArray temporary returned by Abstract_Binary_Operator
  //     2. Lhs is used to get the Lhs partition information (PARTI parallel descriptor) and array reuse
  //     3. Rhs is used to get the Rhs partition information (PARTI parallel descriptor) in case the Lhs was 
  //        a NULL array (no data and no defined partitioning (i.e. no PARTI parallel descriptor)) and array reuse
  //     4. The floatSerialArray which is to be put into the floatArray temporary returned by Abstract_Binary_Operator
  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, sign(*Lhs_SerialArray,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, sign(*Lhs_SerialArray,*Rhs_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
  // if (Lhs_SerialArray != Return_Value.getSerialArrayPointer())
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & sign(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator_Non_Commutative ( Lhs , Rhs , MDI_f_Sign_Array_Of_Array, MDI_f_Sign_Array_Of_Array_Accumulate_To_Operand , floatSerialArray::sign_Function );
#endif
   }




floatSerialArray &
sign ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\nInside of sign (float,floatSerialArray) for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in sign");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & sign(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
              (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}

        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & sign(float,floatSerialArray)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, sign(x,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, sign(x,*Rhs_SerialArray) );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value (before delete macro) in floatSerialArray & sign(float,floatSerialArray)");
        }
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & sign(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator_Non_Commutative ( Rhs , x ,
               MDI_f_Sign_Scalar_Of_Array,
               MDI_f_Sign_Scalar_Of_Array_Accumulate_To_Operand , floatSerialArray::Scalar_sign_Function );
#endif
   }




floatSerialArray &
sign ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of sign (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in sign");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts 
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & sign(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & sign(floatSerialArray,float)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, sign(*Lhs_SerialArray,x) );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in floatSerialArray & sign ( const floatSerialArray & Lhs , float x )");
#endif
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, sign(*Lhs_SerialArray,x) );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & sign(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x ,
               MDI_f_Sign_Array_Of_Scalar,
               MDI_f_Sign_Array_Of_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_sign_Function );
#endif
   }


floatSerialArray &
floatSerialArray::operator+= ( float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator+= (float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator+=");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator+=(float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( *this , This_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( *this , This_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, This_SerialArray, *This_SerialArray += x );
     // ... don't need to use macro because Return_Value won't be Mask ...
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;

#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , x ,
        MDI_f_Add_Array_Plus_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_Plus_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator+=(float)");
        }
#endif

     return *this;
   }


// Most C++ compliers support a unary plus operator
floatSerialArray &
floatSerialArray::operator+ () const
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of unary plus floatSerialArray::operator+ () for floatSerialArray class! \n");
#endif

  // return *this;
     return (floatSerialArray &)(*this);
   }


floatSerialArray &
min ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of min (floatSerialArray,floatSerialArray) for floatSerialArray class! Lhs:rc=%d Rhs:rc=%d ",
               Lhs.getRawDataReferenceCount(),Rhs.getRawDataReferenceCount());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in min");
     Rhs.Test_Consistency ("Test Rhs in min");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & min(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & min(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs and Rhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
	       puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
                     Rhs, Rhs_SerialArray );
             }

          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

  // New test (8/5/2000)
     APP_ASSERT(Temporary_Array_Set != NULL);
  // Temporary_Array_Set->display("Check to see what sort of communication model was used");

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & min(floatSerialArray,floatSerialArray)");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & min(floatSerialArray,floatSerialArray)");
        }
#endif

  // Inputs to floatArray::Abstract_Binary_Operator:
  //     1. Temporary_Array_Set is attached to the floatArray temporary returned by Abstract_Binary_Operator
  //     2. Lhs is used to get the Lhs partition information (PARTI parallel descriptor) and array reuse
  //     3. Rhs is used to get the Rhs partition information (PARTI parallel descriptor) in case the Lhs was 
  //        a NULL array (no data and no defined partitioning (i.e. no PARTI parallel descriptor)) and array reuse
  //     4. The floatSerialArray which is to be put into the floatArray temporary returned by Abstract_Binary_Operator
  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, min(*Lhs_SerialArray,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, min(*Lhs_SerialArray,*Rhs_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
  // if (Lhs_SerialArray != Return_Value.getSerialArrayPointer())
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & min(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , Rhs , MDI_f_Min_Array_And_Array, MDI_f_Min_Array_And_Array_Accumulate_To_Operand , floatSerialArray::min_Function );
#endif
   }


floatSerialArray &
min ( const floatSerialArray & X , const floatSerialArray & Y , const floatSerialArray & Z )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of min (floatSerialArray,floatSerialArray,floatSerialArray) for class! X:rc=%d Y:rc=%d Z:rc=%d ",
               X.getRawDataReferenceCount(),Y.getRawDataReferenceCount(),Z.getRawDataReferenceCount());
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
        {
          X.Test_Conformability (Y);
          X.Test_Conformability (Z);
        }
     
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & min (floatSerialArray,floatSerialArray,floatSerialArray)");
          Y.displayReferenceCounts("Y in floatSerialArray & min (floatSerialArray,floatSerialArray,floatSerialArray)");
          Z.displayReferenceCounts("Z in floatSerialArray & min (floatSerialArray,floatSerialArray,floatSerialArray)");
        }
#endif

     return min ( X , min ( Y , Z ) );
   }


floatSerialArray &
min ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\nInside of min (float,floatSerialArray) for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in min");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & min(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
              (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}

        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & min(float,floatSerialArray)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, min(x,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, min(x,*Rhs_SerialArray) );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value (before delete macro) in floatSerialArray & min(float,floatSerialArray)");
        }
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & min(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator ( Rhs , x ,
               MDI_f_Min_Scalar_And_Array,
               MDI_f_Min_Scalar_And_Array_Accumulate_To_Operand , floatSerialArray::Scalar_min_Function );
#endif
   }


floatSerialArray &
min ( float x , const floatSerialArray & Y , const floatSerialArray & Z )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of min (float,floatSerialArray,floatSerialArray) for class! Y:rc=%d Z:rc=%d ",
               Y.getRawDataReferenceCount(),Z.getRawDataReferenceCount());
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Y.Test_Conformability (Z);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Y.displayReferenceCounts("Y in floatSerialArray & min (float,floatSerialArray,floatSerialArray)");
          Z.displayReferenceCounts("Z in floatSerialArray & min (float,floatSerialArray,floatSerialArray)");
        }
#endif

     return min ( x , min ( Y , Z ) );
   }


floatSerialArray &
min ( const floatSerialArray & X , float y , const floatSerialArray & Z )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of min (floatSerialArray,float,floatSerialArray) for class! X:rc=%d Z:rc=%d ",
               X.getRawDataReferenceCount(),Z.getRawDataReferenceCount());
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          X.Test_Conformability (Z);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & min (float,floatSerialArray,floatSerialArray)");
          Z.displayReferenceCounts("Z in floatSerialArray & min (float,floatSerialArray,floatSerialArray)");
        }
#endif

     return min ( y , min ( X , Z ) );
   }


floatSerialArray &
min ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of min (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in min");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts 
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & min(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & min(floatSerialArray,float)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, min(*Lhs_SerialArray,x) );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in floatSerialArray & min ( const floatSerialArray & Lhs , float x )");
#endif
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, min(*Lhs_SerialArray,x) );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & min(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x ,
               MDI_f_Min_Array_And_Scalar,
               MDI_f_Min_Array_And_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_min_Function );
#endif
   }


floatSerialArray &
min ( const floatSerialArray & X , const floatSerialArray & Y , float z )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of min (floatSerialArray,floatSerialArray,float) for class! X:rc=%d Y:rc=%d ",
               X.getRawDataReferenceCount(),Y.getRawDataReferenceCount());
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          X.Test_Conformability (Y);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & min (floatSerialArray,floatSerialArray,float)");
          Y.displayReferenceCounts("Y in floatSerialArray & min (floatSerialArray,floatSerialArray,float)");
        }
#endif

     return min ( min ( X , Y ) , z );
   }


float
min ( const floatSerialArray & X )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of min (floatSerialArray) returning float for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in min (const floatSerialArray & X)");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in float min (floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	          (X, X_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
                    (X, X_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

     if (Temporary_Array_Set == NULL)
        {
          Temporary_Array_Set = new Array_Conformability_Info_Type();
        }

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // We need to specify the type of operation so that the reduction operation between processors can be handled correctly
#if defined(MEMORY_LEAK_TEST)
     float Return_Value = 0;
#else
     float Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, min (*X_SerialArray) , floatSerialArray::min_Function );
  // return floatArray::Abstract_Reduction_Operator ( Temporary_Array_Set, X, min (*X_SerialArray) , floatSerialArray::min_Function );
#endif

  // Delete the serial array unless it would have been absorbed by the serialArray in function
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
       {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X , MDI_f_Min_Array_Returning_Scalar , floatSerialArray::min_Function );
#endif
   }


floatSerialArray &
max ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of max (floatSerialArray,floatSerialArray) for floatSerialArray class! Lhs:rc=%d Rhs:rc=%d ",
               Lhs.getRawDataReferenceCount(),Rhs.getRawDataReferenceCount());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in max");
     Rhs.Test_Consistency ("Test Rhs in max");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & max(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & max(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs and Rhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
	       puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
                     Rhs, Rhs_SerialArray );
             }

          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

  // New test (8/5/2000)
     APP_ASSERT(Temporary_Array_Set != NULL);
  // Temporary_Array_Set->display("Check to see what sort of communication model was used");

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & max(floatSerialArray,floatSerialArray)");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & max(floatSerialArray,floatSerialArray)");
        }
#endif

  // Inputs to floatArray::Abstract_Binary_Operator:
  //     1. Temporary_Array_Set is attached to the floatArray temporary returned by Abstract_Binary_Operator
  //     2. Lhs is used to get the Lhs partition information (PARTI parallel descriptor) and array reuse
  //     3. Rhs is used to get the Rhs partition information (PARTI parallel descriptor) in case the Lhs was 
  //        a NULL array (no data and no defined partitioning (i.e. no PARTI parallel descriptor)) and array reuse
  //     4. The floatSerialArray which is to be put into the floatArray temporary returned by Abstract_Binary_Operator
  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, max(*Lhs_SerialArray,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, max(*Lhs_SerialArray,*Rhs_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
  // if (Lhs_SerialArray != Return_Value.getSerialArrayPointer())
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & max(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , Rhs , MDI_f_Max_Array_And_Array, MDI_f_Max_Array_And_Array_Accumulate_To_Operand , floatSerialArray::max_Function );
#endif
   }


floatSerialArray &
max ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\nInside of max (float,floatSerialArray) for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in max");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & max(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
              (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}

        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & max(float,floatSerialArray)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, max(x,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, max(x,*Rhs_SerialArray) );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value (before delete macro) in floatSerialArray & max(float,floatSerialArray)");
        }
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & max(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator ( Rhs , x ,
               MDI_f_Max_Scalar_And_Array,
               MDI_f_Max_Scalar_And_Array_Accumulate_To_Operand , floatSerialArray::Scalar_max_Function );
#endif
   }


floatSerialArray &
max ( float x , const floatSerialArray & Y , const floatSerialArray & Z )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of max (float,floatSerialArray,floatSerialArray) for floatSerialArray class!");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Y.Test_Conformability (Z);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Y.displayReferenceCounts("Y in floatSerialArray & max (float,floatSerialArray,floatSerialArray)");
          Z.displayReferenceCounts("Z in floatSerialArray & max (float,floatSerialArray,floatSerialArray)");
        }
#endif

     return max ( x , max ( Y , Z ) );
   }


floatSerialArray &
max ( const floatSerialArray & X , float y , const floatSerialArray & Z )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of max (floatSerialArray,float,floatSerialArray) for floatSerialArray class!");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          X.Test_Conformability (Z);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & max (float,floatSerialArray,floatSerialArray)");
          Z.displayReferenceCounts("Z in floatSerialArray & max (float,floatSerialArray,floatSerialArray)");
        }
#endif

     return max ( y , max ( X , Z ) );
   }


floatSerialArray &
max ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of max (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in max");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts 
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & max(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & max(floatSerialArray,float)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, max(*Lhs_SerialArray,x) );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in floatSerialArray & max ( const floatSerialArray & Lhs , float x )");
#endif
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, max(*Lhs_SerialArray,x) );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & max(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x ,
               MDI_f_Max_Array_And_Scalar,
               MDI_f_Max_Array_And_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_max_Function );
#endif
   }


floatSerialArray &
max ( const floatSerialArray & X , const floatSerialArray & Y , float z )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of max (floatSerialArray,floatSerialArray,float) for floatSerialArray class! \n");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          X.Test_Conformability (Y);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & max (floatSerialArray,floatSerialArray,float)");
          Y.displayReferenceCounts("Y in floatSerialArray & max (floatSerialArray,floatSerialArray,float)");
        }
#endif

     return max ( max ( X , Y ) , z );
   }


float
max ( const floatSerialArray & X )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of max (floatSerialArray) returning float for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in max (const floatSerialArray & X)");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in float max (floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
             }
	    else
	     {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement (X, X_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	            (X, X_SerialArray, 
                     *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	     }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

     if (Temporary_Array_Set == NULL)
        {
       // printf ("Building the Array_Set in the max operator \n");
          Temporary_Array_Set =	new Array_Conformability_Info_Type();
        }

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray       != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     float Return_Value = 0;
#else
     float Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, max (*X_SerialArray) , floatSerialArray::max_Function );
#endif

  // Delete the serial array unless it would have been absorbed by the serialArray in function
     if (xIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X , MDI_f_Max_Array_Returning_Scalar , floatSerialArray::max_Function );
#endif
   }


floatSerialArray &
max ( const floatSerialArray & X , const floatSerialArray & Y , const floatSerialArray & Z )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of max (floatSerialArray,floatSerialArray,floatSerialArray) for floatSerialArray class! \n");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
        {
          X.Test_Conformability (Y);
          X.Test_Conformability (Z);
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in floatSerialArray & max (floatSerialArray,floatSerialArray,floatSerialArray)");
          Y.displayReferenceCounts("Y in floatSerialArray & max (floatSerialArray,floatSerialArray,floatSerialArray)");
          Z.displayReferenceCounts("Z in floatSerialArray & max (floatSerialArray,floatSerialArray,floatSerialArray)");
        }
#endif

     return max ( X , max ( Y , Z ) );
   }


float
sum ( const floatSerialArray & X )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of sum (const floatSerialArray) returning float for floatSerialArray class!");

  // This is the only test we can do on the input!
     X.Test_Consistency ("Test X in sum (const floatSerialArray & X)");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          X.displayReferenceCounts("X in float sum (floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *X_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( X, X_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( X, X_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if (X.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
                    (X, X_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
	    else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
                    (X, X_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(X_SerialArray != NULL);

     bool xIsTemporary = X_SerialArray->isTemporary();

     APP_ASSERT ( (xIsTemporary == TRUE) || (xIsTemporary == FALSE) );

  // This bug is fixed in the floatSerialArray::Parallel_Conformability_Enforcement function by restricting the
  // view of the serial array returned to the non ghost boundary portion of the array.
  // If we did that then A = -A would require message passing to update the ghost boundaries.
  // So have to fix it here more directly.
  // Bugfix (2/7/96) P++ must avoid counting the ghost boundaries when performing reduction operations!
     Index_Pointer_Array_MAX_ARRAY_DIMENSION_Type Index_Pointer_List;
     for (int i=0; i < MAX_ARRAY_DIMENSION; i++)
        {
       // Index_Pointer_List[i] = &(X.Array_Descriptor.Array_Domain.Local_Mask_Index[i]);
       // This is all a lot more complex if the stride is not the unit stride! 
       // So for now we avoid this case.
          int Ghost_Boundary_Width = X.Array_Descriptor.Array_Domain.InternalGhostCellWidth[i];
          int Local_Base  = X.getLocalBase(i);
          int Local_Bound = X.getLocalBound(i);

       // Left and right edges do not  i n c l u d e  a ghost boundary!
          if (X.Array_Descriptor.Array_Domain.isLeftPartition(i) == FALSE)
             Local_Base += Ghost_Boundary_Width;
          if (X.Array_Descriptor.Array_Domain.isRightPartition(i) == FALSE)
             Local_Bound -= Ghost_Boundary_Width;
       // APP_ASSERT(Local_Base <= Local_Bound);
       // ... (12/27/96,kdb) only valid value might be on a ghost cell so make a NULL INDEX in this case ...
          if (Local_Base <= Local_Bound)
               Index_Pointer_List[i] = new Range (Local_Base,Local_Bound);
            else
               Index_Pointer_List[i] = new Internal_Index (Local_Base,0);
#if 0
          APP_ASSERT (X.Array_Descriptor.Array_Domain.Stride[i] == 1);
#else
       // Now take the intersection of this with the local mask
          (*Index_Pointer_List[i]) = (*Index_Pointer_List[i])(X.Array_Descriptor.Array_Domain.Local_Mask_Index[i]);
#endif
        }

#if defined(MEMORY_LEAK_TEST)
     float Return_Value = 0;
#else
  // Note that we hand the sum operator a view and this means we have
  // to delete the X_SerialArray explicitly (unlike other operators)
     float Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, X, X_SerialArray, sum ((*X_SerialArray)(Index_Pointer_List)) , floatSerialArray::sum_Function );
#endif

     for (int k=0; k < MAX_ARRAY_DIMENSION; k++)
        {
          if (Index_Pointer_List[k] != NULL)
             {
               delete Index_Pointer_List[k];
               Index_Pointer_List[k] = NULL;
             }
        }

  // Note that a view is handed into the sum operator (so this is not dependent upon the value of xIsTemporary)
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): X_SerialArray->getReferenceCount() = %d \n",
       //      X_SerialArray->getReferenceCount());

       // Must delete the X_SerialArray if it was taken directly from the X array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (X_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          X_SerialArray->decrementReferenceCount();
          if (X_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete X_SerialArray;
             }
          X_SerialArray = NULL;


  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( X , MDI_f_Sum_Array_Returning_Scalar , floatSerialArray::sum_Function );
#endif
   }


intSerialArray &
floatSerialArray::operator! ()
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator! for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operatoroperator!");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in intSerialArray & floatSerialArray::operator!()");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
	       Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( *this, This_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( *this, This_SerialArray);
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement (
                    *this, This_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask,
                    Mask_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	          ( *this, This_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask,
                    Mask_SerialArray);
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

     if (Temporary_Array_Set == NULL) Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray    != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, *this, This_SerialArray->operator!() );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in intSerialArray & floatSerialArray::operator! ()");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, *this, This_SerialArray, This_SerialArray->operator!() );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }
     
  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & floatSerialArray::operator!()");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator_Returning_IntArray ( *this ,
                   MDI_f_NOT_Array_Returning_IntArray ,
                   MDI_f_NOT_Array_Accumulate_To_Operand_Returning_IntArray , 
                   floatSerialArray::Not );
#endif
   }


floatSerialArray &
operator- ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator- (floatSerialArray,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator-");
     Rhs.Test_Consistency ("Test Rhs in operator-");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator-(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator-(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;
     floatSerialArray* Rhs_SerialArray = NULL;

     intSerialArray* Mask_SerialArray = NULL;
     intSerialArray* Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	    (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
        {
	   puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
           APP_ABORT();
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
	       Rhs, Rhs_SerialArray );
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, *Lhs_SerialArray - *Rhs_SerialArray );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator 
	( Temporary_Array_Set, Lhs, Rhs, 
	  Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray - *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator-(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Non_Commutative ( Lhs , Rhs , 
               MDI_f_Subtract_Array_Minus_Array,
               MDI_f_Subtract_Array_Minus_Array_Accumulate_To_Operand , floatSerialArray::Minus );
#endif
   }


intSerialArray &
operator< ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {   
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of operator< (floatSerialArray(id=%d),floatSerialArray(id=%d)) for floatSerialArray class!",
               Lhs.Array_ID(),Rhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator< (floatSerialArray,floatSerialArray)");
     Rhs.Test_Consistency ("Test Rhs in operator< (floatSerialArray,floatSerialArray)");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator<(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator<(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

  // printf ("Checking if WHERE statement is used before calling SerialArray::Parallel_Conformability_Enforcement from operator< \n");

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
       // printf ("Checking if indirect addressing is used before calling SerialArray::Parallel_Conformability_Enforcement from operator< \n");
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               printf ("ERROR: can't mix indirect addressing with 2 arrays and where. \n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Lhs_SerialArray     != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);
     APP_ASSERT(Temporary_Array_Set != NULL);

#if 0
     Lhs.displayReferenceCounts ("Lhs after PCE in operator< (floatSerialArray,floatSerialArray)");
     Rhs.displayReferenceCounts ("Rhs after PCE in operator< (floatSerialArray,floatSerialArray)");
     Lhs_SerialArray->displayReferenceCounts ("Lhs_SerialArray after PCE in operator< (floatSerialArray,floatSerialArray)");
     Rhs_SerialArray->displayReferenceCounts ("Rhs_SerialArray after PCE in operator< (floatSerialArray,floatSerialArray)");
#endif

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator< ( const floatSerialArray & Lhs , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray < *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;


  // Since the Rhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in operator< (floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , Rhs ,
               MDI_f_LT_Array_LT_Array,
               MDI_f_LT_Array_LT_Array_Accumulate_To_Operand , floatSerialArray::LT );
#endif
   }   


intSerialArray &
operator< ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator< (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator< (floatSerialArray,float)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator<(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, *Lhs_SerialArray < x );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator< ( const floatSerialArray & Lhs , float x )");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, *Lhs_SerialArray < x );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator<(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , x ,
               MDI_f_LT_Array_LT_Scalar,
               MDI_f_LT_Array_LT_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_LT );
#endif
   }


intSerialArray &
operator< ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator< (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator< (float,floatSerialArray)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator<(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator< ( float x , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x < *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator<(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Rhs , x ,
               MDI_f_LT_Scalar_LT_Array,
               MDI_f_LT_Scalar_LT_Array_Accumulate_To_Operand , floatSerialArray::Scalar_LT );
#endif
   }


intSerialArray &
operator> ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {   
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of operator> (floatSerialArray(id=%d),floatSerialArray(id=%d)) for floatSerialArray class!",
               Lhs.Array_ID(),Rhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator> (floatSerialArray,floatSerialArray)");
     Rhs.Test_Consistency ("Test Rhs in operator> (floatSerialArray,floatSerialArray)");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator>(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator>(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

  // printf ("Checking if WHERE statement is used before calling SerialArray::Parallel_Conformability_Enforcement from operator> \n");

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
       // printf ("Checking if indirect addressing is used before calling SerialArray::Parallel_Conformability_Enforcement from operator> \n");
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               printf ("ERROR: can't mix indirect addressing with 2 arrays and where. \n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Lhs_SerialArray     != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);
     APP_ASSERT(Temporary_Array_Set != NULL);

#if 0
     Lhs.displayReferenceCounts ("Lhs after PCE in operator> (floatSerialArray,floatSerialArray)");
     Rhs.displayReferenceCounts ("Rhs after PCE in operator> (floatSerialArray,floatSerialArray)");
     Lhs_SerialArray->displayReferenceCounts ("Lhs_SerialArray after PCE in operator> (floatSerialArray,floatSerialArray)");
     Rhs_SerialArray->displayReferenceCounts ("Rhs_SerialArray after PCE in operator> (floatSerialArray,floatSerialArray)");
#endif

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator> ( const floatSerialArray & Lhs , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray > *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;


  // Since the Rhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in operator> (floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , Rhs ,
               MDI_f_GT_Array_GT_Array,
               MDI_f_GT_Array_GT_Array_Accumulate_To_Operand , floatSerialArray::GT );
#endif
   }   


intSerialArray &
operator> ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator> (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator> (floatSerialArray,float)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator>(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, *Lhs_SerialArray > x );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator> ( const floatSerialArray & Lhs , float x )");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, *Lhs_SerialArray > x );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator>(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , x ,
               MDI_f_GT_Array_GT_Scalar,
               MDI_f_GT_Array_GT_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_GT );
#endif
   }


intSerialArray &
operator> ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator> (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator> (float,floatSerialArray)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator>(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator> ( float x , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x > *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator>(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Rhs , x ,
               MDI_f_GT_Scalar_GT_Array,
               MDI_f_GT_Scalar_GT_Array_Accumulate_To_Operand , floatSerialArray::Scalar_GT );
#endif
   }


intSerialArray &
operator<= ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {   
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of operator<= (floatSerialArray(id=%d),floatSerialArray(id=%d)) for floatSerialArray class!",
               Lhs.Array_ID(),Rhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator<= (floatSerialArray,floatSerialArray)");
     Rhs.Test_Consistency ("Test Rhs in operator<= (floatSerialArray,floatSerialArray)");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator<=(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator<=(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

  // printf ("Checking if WHERE statement is used before calling SerialArray::Parallel_Conformability_Enforcement from operator<= \n");

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
       // printf ("Checking if indirect addressing is used before calling SerialArray::Parallel_Conformability_Enforcement from operator<= \n");
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               printf ("ERROR: can't mix indirect addressing with 2 arrays and where. \n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Lhs_SerialArray     != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);
     APP_ASSERT(Temporary_Array_Set != NULL);

#if 0
     Lhs.displayReferenceCounts ("Lhs after PCE in operator<= (floatSerialArray,floatSerialArray)");
     Rhs.displayReferenceCounts ("Rhs after PCE in operator<= (floatSerialArray,floatSerialArray)");
     Lhs_SerialArray->displayReferenceCounts ("Lhs_SerialArray after PCE in operator<= (floatSerialArray,floatSerialArray)");
     Rhs_SerialArray->displayReferenceCounts ("Rhs_SerialArray after PCE in operator<= (floatSerialArray,floatSerialArray)");
#endif

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator<= ( const floatSerialArray & Lhs , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray <= *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;


  // Since the Rhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in operator<= (floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , Rhs ,
               MDI_f_LTEQ_Array_LTEQ_Array,
               MDI_f_LTEQ_Array_LTEQ_Array_Accumulate_To_Operand , floatSerialArray::LTEQ );
#endif
   }   


intSerialArray &
operator<= ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator<= (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator<= (floatSerialArray,float)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator<=(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, *Lhs_SerialArray <= x );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator<= ( const floatSerialArray & Lhs , float x )");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, *Lhs_SerialArray <= x );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator<=(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , x ,
               MDI_f_LTEQ_Array_LTEQ_Scalar,
               MDI_f_LTEQ_Array_LTEQ_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_LTEQ );
#endif
   }


intSerialArray &
operator<= ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator<= (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator<= (float,floatSerialArray)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator<=(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator<= ( float x , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x <= *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator<=(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Rhs , x ,
               MDI_f_LTEQ_Scalar_LTEQ_Array,
               MDI_f_LTEQ_Scalar_LTEQ_Array_Accumulate_To_Operand , floatSerialArray::Scalar_LTEQ );
#endif
   }


intSerialArray &
operator>= ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {   
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of operator>= (floatSerialArray(id=%d),floatSerialArray(id=%d)) for floatSerialArray class!",
               Lhs.Array_ID(),Rhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator>= (floatSerialArray,floatSerialArray)");
     Rhs.Test_Consistency ("Test Rhs in operator>= (floatSerialArray,floatSerialArray)");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator>=(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator>=(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

  // printf ("Checking if WHERE statement is used before calling SerialArray::Parallel_Conformability_Enforcement from operator>= \n");

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
       // printf ("Checking if indirect addressing is used before calling SerialArray::Parallel_Conformability_Enforcement from operator>= \n");
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               printf ("ERROR: can't mix indirect addressing with 2 arrays and where. \n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Lhs_SerialArray     != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);
     APP_ASSERT(Temporary_Array_Set != NULL);

#if 0
     Lhs.displayReferenceCounts ("Lhs after PCE in operator>= (floatSerialArray,floatSerialArray)");
     Rhs.displayReferenceCounts ("Rhs after PCE in operator>= (floatSerialArray,floatSerialArray)");
     Lhs_SerialArray->displayReferenceCounts ("Lhs_SerialArray after PCE in operator>= (floatSerialArray,floatSerialArray)");
     Rhs_SerialArray->displayReferenceCounts ("Rhs_SerialArray after PCE in operator>= (floatSerialArray,floatSerialArray)");
#endif

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator>= ( const floatSerialArray & Lhs , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray >= *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;


  // Since the Rhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in operator>= (floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , Rhs ,
               MDI_f_GTEQ_Array_GTEQ_Array,
               MDI_f_GTEQ_Array_GTEQ_Array_Accumulate_To_Operand , floatSerialArray::GTEQ );
#endif
   }   


floatSerialArray &
operator- ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator- (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator-");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator-(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = 
	      floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray     != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, *Lhs_SerialArray - x );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator-(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x , 
               MDI_f_Subtract_Array_Minus_Scalar,
               MDI_f_Subtract_Array_Minus_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_Minus );
#endif
   }


intSerialArray &
operator>= ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator>= (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator>= (floatSerialArray,float)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator>=(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, *Lhs_SerialArray >= x );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator>= ( const floatSerialArray & Lhs , float x )");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, *Lhs_SerialArray >= x );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator>=(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , x ,
               MDI_f_GTEQ_Array_GTEQ_Scalar,
               MDI_f_GTEQ_Array_GTEQ_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_GTEQ );
#endif
   }


intSerialArray &
operator>= ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator>= (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator>= (float,floatSerialArray)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator>=(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator>= ( float x , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x >= *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator>=(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Rhs , x ,
               MDI_f_GTEQ_Scalar_GTEQ_Array,
               MDI_f_GTEQ_Scalar_GTEQ_Array_Accumulate_To_Operand , floatSerialArray::Scalar_GTEQ );
#endif
   }


intSerialArray &
operator== ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {   
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of operator== (floatSerialArray(id=%d),floatSerialArray(id=%d)) for floatSerialArray class!",
               Lhs.Array_ID(),Rhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator== (floatSerialArray,floatSerialArray)");
     Rhs.Test_Consistency ("Test Rhs in operator== (floatSerialArray,floatSerialArray)");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator==(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator==(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

  // printf ("Checking if WHERE statement is used before calling SerialArray::Parallel_Conformability_Enforcement from operator== \n");

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
       // printf ("Checking if indirect addressing is used before calling SerialArray::Parallel_Conformability_Enforcement from operator== \n");
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               printf ("ERROR: can't mix indirect addressing with 2 arrays and where. \n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Lhs_SerialArray     != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);
     APP_ASSERT(Temporary_Array_Set != NULL);

#if 0
     Lhs.displayReferenceCounts ("Lhs after PCE in operator== (floatSerialArray,floatSerialArray)");
     Rhs.displayReferenceCounts ("Rhs after PCE in operator== (floatSerialArray,floatSerialArray)");
     Lhs_SerialArray->displayReferenceCounts ("Lhs_SerialArray after PCE in operator== (floatSerialArray,floatSerialArray)");
     Rhs_SerialArray->displayReferenceCounts ("Rhs_SerialArray after PCE in operator== (floatSerialArray,floatSerialArray)");
#endif

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator== ( const floatSerialArray & Lhs , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray == *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;


  // Since the Rhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in operator== (floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , Rhs ,
               MDI_f_EQ_Array_EQ_Array,
               MDI_f_EQ_Array_EQ_Array_Accumulate_To_Operand , floatSerialArray::EQ );
#endif
   }   


intSerialArray &
operator== ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator== (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator== (floatSerialArray,float)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator==(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, *Lhs_SerialArray == x );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator== ( const floatSerialArray & Lhs , float x )");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, *Lhs_SerialArray == x );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator==(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , x ,
               MDI_f_EQ_Array_EQ_Scalar,
               MDI_f_EQ_Array_EQ_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_EQ );
#endif
   }


intSerialArray &
operator== ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator== (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator== (float,floatSerialArray)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator==(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator== ( float x , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x == *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator==(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Rhs , x ,
               MDI_f_EQ_Scalar_EQ_Array,
               MDI_f_EQ_Scalar_EQ_Array_Accumulate_To_Operand , floatSerialArray::Scalar_EQ );
#endif
   }


intSerialArray &
operator!= ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {   
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of operator!= (floatSerialArray(id=%d),floatSerialArray(id=%d)) for floatSerialArray class!",
               Lhs.Array_ID(),Rhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator!= (floatSerialArray,floatSerialArray)");
     Rhs.Test_Consistency ("Test Rhs in operator!= (floatSerialArray,floatSerialArray)");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator!=(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator!=(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

  // printf ("Checking if WHERE statement is used before calling SerialArray::Parallel_Conformability_Enforcement from operator!= \n");

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
       // printf ("Checking if indirect addressing is used before calling SerialArray::Parallel_Conformability_Enforcement from operator!= \n");
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               printf ("ERROR: can't mix indirect addressing with 2 arrays and where. \n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Lhs_SerialArray     != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);
     APP_ASSERT(Temporary_Array_Set != NULL);

#if 0
     Lhs.displayReferenceCounts ("Lhs after PCE in operator!= (floatSerialArray,floatSerialArray)");
     Rhs.displayReferenceCounts ("Rhs after PCE in operator!= (floatSerialArray,floatSerialArray)");
     Lhs_SerialArray->displayReferenceCounts ("Lhs_SerialArray after PCE in operator!= (floatSerialArray,floatSerialArray)");
     Rhs_SerialArray->displayReferenceCounts ("Rhs_SerialArray after PCE in operator!= (floatSerialArray,floatSerialArray)");
#endif

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator!= ( const floatSerialArray & Lhs , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray != *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;


  // Since the Rhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in operator!= (floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , Rhs ,
               MDI_f_NOT_EQ_Array_NOT_EQ_Array,
               MDI_f_NOT_EQ_Array_NOT_EQ_Array_Accumulate_To_Operand , floatSerialArray::NOT_EQ );
#endif
   }   


intSerialArray &
operator!= ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator!= (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator!= (floatSerialArray,float)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator!=(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, *Lhs_SerialArray != x );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator!= ( const floatSerialArray & Lhs , float x )");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, *Lhs_SerialArray != x );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator!=(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , x ,
               MDI_f_NOT_EQ_Array_NOT_EQ_Scalar,
               MDI_f_NOT_EQ_Array_NOT_EQ_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_NOT_EQ );
#endif
   }


intSerialArray &
operator!= ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator!= (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator!= (float,floatSerialArray)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator!=(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator!= ( float x , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x != *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator!=(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Rhs , x ,
               MDI_f_NOT_EQ_Scalar_NOT_EQ_Array,
               MDI_f_NOT_EQ_Scalar_NOT_EQ_Array_Accumulate_To_Operand , floatSerialArray::Scalar_NOT_EQ );
#endif
   }


intSerialArray &
operator&& ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {   
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of operator&& (floatSerialArray(id=%d),floatSerialArray(id=%d)) for floatSerialArray class!",
               Lhs.Array_ID(),Rhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator&& (floatSerialArray,floatSerialArray)");
     Rhs.Test_Consistency ("Test Rhs in operator&& (floatSerialArray,floatSerialArray)");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator&&(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator&&(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

  // printf ("Checking if WHERE statement is used before calling SerialArray::Parallel_Conformability_Enforcement from operator&& \n");

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
       // printf ("Checking if indirect addressing is used before calling SerialArray::Parallel_Conformability_Enforcement from operator&& \n");
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               printf ("ERROR: can't mix indirect addressing with 2 arrays and where. \n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Lhs_SerialArray     != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);
     APP_ASSERT(Temporary_Array_Set != NULL);

#if 0
     Lhs.displayReferenceCounts ("Lhs after PCE in operator&& (floatSerialArray,floatSerialArray)");
     Rhs.displayReferenceCounts ("Rhs after PCE in operator&& (floatSerialArray,floatSerialArray)");
     Lhs_SerialArray->displayReferenceCounts ("Lhs_SerialArray after PCE in operator&& (floatSerialArray,floatSerialArray)");
     Rhs_SerialArray->displayReferenceCounts ("Rhs_SerialArray after PCE in operator&& (floatSerialArray,floatSerialArray)");
#endif

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator&& ( const floatSerialArray & Lhs , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray && *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;


  // Since the Rhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in operator&& (floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , Rhs ,
               MDI_f_AND_Array_AND_Array,
               MDI_f_AND_Array_AND_Array_Accumulate_To_Operand , floatSerialArray::AND );
#endif
   }   


intSerialArray &
operator&& ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator&& (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator&& (floatSerialArray,float)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator&&(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, *Lhs_SerialArray && x );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator&& ( const floatSerialArray & Lhs , float x )");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, *Lhs_SerialArray && x );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator&&(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , x ,
               MDI_f_AND_Array_AND_Scalar,
               MDI_f_AND_Array_AND_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_AND );
#endif
   }


floatSerialArray &
operator- ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of operator- (float,floatSerialArray) for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator-");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator-(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Rhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = 
	      floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL) Temporary_Array_Set =
	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x - *Rhs_SerialArray );
  // return floatArray::Abstract_Binary_Operator ( Temporary_Array_Set, Rhs, x - *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator-(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Rhs , x , 
               MDI_f_Subtract_Scalar_Minus_Array,
               MDI_f_Subtract_Scalar_Minus_Array_Accumulate_To_Operand , floatSerialArray::Scalar_Minus );
#endif
   }


intSerialArray &
operator&& ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator&& (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator&& (float,floatSerialArray)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator&&(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator&& ( float x , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x && *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator&&(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Rhs , x ,
               MDI_f_AND_Scalar_AND_Array,
               MDI_f_AND_Scalar_AND_Array_Accumulate_To_Operand , floatSerialArray::Scalar_AND );
#endif
   }


intSerialArray &
operator|| ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {   
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of operator|| (floatSerialArray(id=%d),floatSerialArray(id=%d)) for floatSerialArray class!",
               Lhs.Array_ID(),Rhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator|| (floatSerialArray,floatSerialArray)");
     Rhs.Test_Consistency ("Test Rhs in operator|| (floatSerialArray,floatSerialArray)");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator||(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator||(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

  // printf ("Checking if WHERE statement is used before calling SerialArray::Parallel_Conformability_Enforcement from operator|| \n");

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
       // printf ("Checking if indirect addressing is used before calling SerialArray::Parallel_Conformability_Enforcement from operator|| \n");
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)|| 
              (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               printf ("ERROR: can't mix indirect addressing with 2 arrays and where. \n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Lhs_SerialArray     != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);
     APP_ASSERT(Temporary_Array_Set != NULL);

#if 0
     Lhs.displayReferenceCounts ("Lhs after PCE in operator|| (floatSerialArray,floatSerialArray)");
     Rhs.displayReferenceCounts ("Rhs after PCE in operator|| (floatSerialArray,floatSerialArray)");
     Lhs_SerialArray->displayReferenceCounts ("Lhs_SerialArray after PCE in operator|| (floatSerialArray,floatSerialArray)");
     Rhs_SerialArray->displayReferenceCounts ("Rhs_SerialArray after PCE in operator|| (floatSerialArray,floatSerialArray)");
#endif

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator|| ( const floatSerialArray & Lhs , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray || *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;


  // Since the Rhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in operator|| (floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , Rhs ,
               MDI_f_OR_Array_OR_Array,
               MDI_f_OR_Array_OR_Array_Accumulate_To_Operand , floatSerialArray::OR );
#endif
   }   


intSerialArray &
operator|| ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator|| (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator|| (floatSerialArray,float)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in intSerialArray & operator||(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, *Lhs_SerialArray || x );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator|| ( const floatSerialArray & Lhs , float x )");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, *Lhs_SerialArray || x );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

#else
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator||(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Lhs , x ,
               MDI_f_OR_Array_OR_Scalar,
               MDI_f_OR_Array_OR_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_OR );
#endif
   }


intSerialArray &
operator|| ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator|| (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator|| (float,floatSerialArray)");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in intSerialArray & operator||(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatSerialArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatSerialArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     printf ("Can't do MEMORY_LEAK_TEST in intSerialArray & operator|| ( float x , const floatSerialArray & Rhs ) \n");
#endif
     intArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x || *Rhs_SerialArray );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
#ifndef INTARRAY
  // Since the Lhs is a different type than the Return Value it could not be reused!
     // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

#else
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }
#endif

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in intSerialArray & operator||(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator_Returning_IntArray ( Rhs , x ,
               MDI_f_OR_Scalar_OR_Array,
               MDI_f_OR_Scalar_OR_Array_Accumulate_To_Operand , floatSerialArray::Scalar_OR );
#endif
   }


// Sum along axis friend function!
floatSerialArray &
sum ( const floatSerialArray & inputArray , int Axis )
{
/*
// ... (Bug Fix, kdb, 7/1/96) Code was previuosly hardwired for 4
//  dimensions, this has been changed to an arbitrary number ...
*/

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          inputArray.displayReferenceCounts("X in floatSerialArray & sum (floatSerialArray,int)");
        }
#endif

//  We want to preserve the interface being for cost array objects but we
// need to use a non-const representation to make this work with the current MDI layer
// so we will cast away cost to make this work.
   floatSerialArray & X = (floatSerialArray &) inputArray;

#if defined(MEMORY_LEAK_TEST)
   puts ("Can't do MEMORY_LEAK_TEST in floatSerialArray & sum ( const floatSerialArray & X , int Axis )");
#endif

//==============================================================
#if COMPILE_DEBUG_STATEMENTS
   if (APP_DEBUG > 0)
      puts ("Inside of floatSerialArray & sum ( const floatSerialArray & X , int Axis ) for floatSerialArray class!");
#endif
//==============================================================

#if defined(PPP)
   // In P++ this function is only implemented for a single processor 
   // case (for now)!
   APP_ASSERT (Communication_Manager::Number_Of_Processors == 1);
#endif

//==============================================================
#if COMPILE_DEBUG_STATEMENTS
   // This is the only test we can do on the input!
   X.Test_Consistency ("Test X in sum (const floatSerialArray & X, int Axis)");
#endif
//==============================================================

   // Build result array (it will be marked as a temporary before we 
   // return)
   floatSerialArray* Result = NULL;

   if (X.Array_Descriptor.Array_Domain.Is_A_Temporary)
   {
      // We could reuse the temporary by taking a view of it (the view 
      // would be of one lower dimension) This avoids any 
      // initialization of the result and the return vaules are 
      // computed in place.

//==============================================================
#if COMPILE_DEBUG_STATEMENTS
      if (APP_DEBUG > 0) puts ("Input is a temporary!");
#endif
//==============================================================
 
      int Base   [MAX_ARRAY_DIMENSION];
      int Length [MAX_ARRAY_DIMENSION];
      int Stride [MAX_ARRAY_DIMENSION];

      int i;
      for (i=0;i<MAX_ARRAY_DIMENSION;i++)
      {
         Base[i]   = X.Array_Descriptor.Array_Domain.Base[i]+
            X.Array_Descriptor.Array_Domain.Data_Base[i];
         Length[i] = (X.Array_Descriptor.Array_Domain.Bound[i]-
            X.Array_Descriptor.Array_Domain.Base[i]) + 1;
         Stride[i] = X.Array_Descriptor.Array_Domain.Stride[i];
      }

      // Increment reference count of data we are building a view of!
      // This allows the temporary to be reused (thus accumulating the 
      // result into the temporary)
      // Note that the we have to delete the temporary at the end of 
      // the function in order to decrement the reference count on the 
      // data.  And since we reuse the temporary we have to increment 
      // (and then decrement) the base along the axis of sumation to 
      // avoid adding the first row to itself.  A nasty detail!

      // SerialArray_Descriptor_Type::Array_Reference_Count_Array 
      //    [X.Array_Descriptor.Array_Domain.Array_ID]++;

      X.incrementRawDataReferenceCount();

//==============================================================
#if COMPILE_DEBUG_STATEMENTS
      if (APP_DEBUG > 0)
        puts ("Do axis specific allocation of temporary!");
#endif
//==============================================================

      // Dimension the array with the specified Axis collapsed
      for (i=0; i<MAX_ARRAY_DIMENSION;i++)
         if (i == Axis)
	 {
	   Length[i] = 1;
	   Stride[i] = 1;
	 }

      Index_Pointer_Array_MAX_ARRAY_DIMENSION_Type Index_List;
      Index Index_Array[MAX_ARRAY_DIMENSION];

      for (i=0; i<MAX_ARRAY_DIMENSION;i++)
      {
         Index_Array[i] = Index (Base[i],Length[i],Stride[i]);
         Index_List[i] = &Index_Array[i];
      }

#if defined(PPP)
      // Must build a view of X.SerialArray to make it consistant 
      // with the P++ descriptor

      // SerialArray_Descriptor_Type::Array_Reference_Count_Array 
      //   [X.SerialArray->Array_Descriptor.Array_Domain.Array_ID]++;

       X.incrementRawDataReferenceCount();
       floatSerialArray *View = new floatSerialArray 
         ( X.Array_Descriptor.SerialArray->Array_Descriptor.Array_Data , 
	   X.Array_Descriptor.SerialArray->Array_Descriptor.Array_Domain,Index_List);
       Result = new floatSerialArray 
         (View , X.Array_Descriptor.Array_Domain,Index_List);
#else
      Result = new floatSerialArray 
         (X.Array_Descriptor.Array_Data , 
	  X.Array_Descriptor.Array_Domain,Index_List);
#endif

     // Modify the Input descriptor to avoid the sum of the first 
     // value along the chosen axis to itself. This allows the MDI 
     // function to accumulate the result into itself thus reusing 
     // the temporary.  But to make this work we have to skip the 
     // sumation of the
     // first row into itself.  A very nasty detail!
     // This should be a issue for any threaded computation (THREAD SAFETY ALERT)

     X.Array_Descriptor.Array_Domain.Base[Axis] += 
	X.Array_Descriptor.Array_Domain.Stride[Axis];

//==============================================================
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
        puts ("DONE with axis specific allocation of temporary!");
#endif
//==============================================================
   }
   else
   {
      Integer_Array_MAX_ARRAY_DIMENSION_Type Integer_List;
      int i;
      for (i=0;i<MAX_ARRAY_DIMENSION;i++)
         Integer_List[i] = X.getLength (i);

      Integer_List[Axis] = 1;

      // Input is not a temporary so we have to build a return array (of 
      // the correct dimensions)
      // Dimension the array with the specified Axis collapsed

      Integer_List[Axis] = 1;
      Result = new floatSerialArray (Integer_List);
   }

#if defined(PPP)
  // Skip this for now since it is sort of complex
  // puts ("P++ sum function (sum along an axis) not completely implemented yet (this function is more complex in P++ and will be done last)!");
  // APP_ABORT();
  // Use avoid compiler warning
  // int Avoid_Compiler_Warning = Axis;
  // Use avoid compiler warning
  // return (floatSerialArray &) X;

  // This could be more efficent!
     APP_ASSERT(Result != NULL);
     APP_ASSERT(Result->Array_Descriptor.SerialArray != NULL);
     //APP_ASSERT(Result->Array_Descriptor != NULL);
     APP_ASSERT(X.Array_Descriptor.SerialArray != NULL);
     //APP_ASSERT(X.Array_Descriptor != NULL);

  // Result->view("Result->view (BEFORE SUM)");
  // Result->SerialArray->view("Result->SerialArray->view");
  // if (X.Array_Descriptor.Array_Domain.Is_A_Temporary == TRUE)
  //      *(Result->SerialArray) = sum ( *(X.SerialArray) , Axis );

  // puts ("Call floatSerialArray sum along axis function!");
  // Mark as a NON-temporary to avoid temporary handling which would absorb the temporary
  // This could be done more efficently by testing for a temporary and skipping the
  // call to the assignment operator! Later!
  // Result->Array_Descriptor.Array_Domain.Is_A_Temporary = FALSE;
     Result->Array_Descriptor.SerialArray->Array_Descriptor.Array_Domain.
	Is_A_Temporary = FALSE;

     APP_ASSERT(Result->Array_Descriptor.SerialArray->Array_Descriptor.
		Array_Domain.Is_A_Temporary == FALSE);
     *(Result->Array_Descriptor.SerialArray) = 
	sum ( *(X.Array_Descriptor.SerialArray) , Axis );
  // Result->view("Result->view (AFTER SUM)");

  // puts ("Returning from floatArray sum along axis!");

  // Mark as a temporary
     Result->Array_Descriptor.Array_Domain.Is_A_Temporary = TRUE;
     Result->Array_Descriptor.SerialArray->Array_Descriptor.Array_Domain.
	Is_A_Temporary = TRUE;

#if COMPILE_DEBUG_STATEMENTS
  // This is the only test we can do on the input!
     Result->Test_Consistency ("Test Result in sum (const floatSerialArray & X, int Axis)");
#endif

     return *Result;
  // End of P++ code
#else
  // Start of A++ code

  // Variables to hold data obtainted from inlined access functions
     int *Mask_Array_Data   = NULL;
     array_domain *Mask_Descriptor   = NULL;

  // Check for Where Mask
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          puts ("In sum(floatfArray,int): Where Mask usage not implemented (it is largely meaningless in this case)!");
          APP_ABORT();
       // Mask_Array_Data = Where_Statement_Support::Where_Statement_Mask->Array_Data;
       // Mask_Descriptor = (int*) Where_Statement_Support::Where_Statement_Mask->Array_Descriptor;
        }

     APP_ASSERT(Result->Array_Descriptor.Array_Data       != NULL);
     APP_ASSERT(X.Array_Descriptor.Array_Data             != NULL);
     //APP_ASSERT(Result->Array_Descriptor                != NULL);
     //APP_ASSERT(X.Array_Descriptor                      != NULL);

  // If the input was not a temporary then a temporary was created (which must be initialized to zero)
     if (X.Array_Descriptor.Array_Domain.Is_A_Temporary == FALSE)
        {
       // Initialize the just allocated temporary to ZERO.  Because this could be a 3D array
       // (one dimension less than the input) this operation is not trivial.  To simplify this
       // we call the MDI function for assignment of a scalar toan array directly.  This would be 
       // more efficient than calling the A++ operator= though this function could be made more
       // efficient if we were to do the initialization in the MDI_f_Sum_Array_Along_Axis function
       // but that would be more complex so I will skip that for now.
          MDI_f_Assign_Array_Equals_Scalar_Accumulate_To_Operand 
	     ( Result->Array_Descriptor.Array_Data , 0 , Mask_Array_Data ,
              (array_domain*) &(Result->Array_Descriptor.Array_Domain) , 
	      Mask_Descriptor );
        }

  // Hand off to the MDI layer for more efficent computation
     MDI_f_Sum_Array_Along_Axis 
	( Axis, Result->Array_Descriptor.Array_Data, X.Array_Descriptor.Array_Data, 
	  Mask_Array_Data, (array_domain*) &(Result->Array_Descriptor.Array_Domain), 
	  (array_domain*) &(X.Array_Descriptor.Array_Domain) , Mask_Descriptor );

  // Bug fix (9/11/94) we reuse the temporary!
  // Delete the input array object if it was a temporary
     if (X.Array_Descriptor.Array_Domain.Is_A_Temporary == TRUE)
        {
       // Above the descriptor was modified to avoid sumation of the first element along
       // the choosen axis with itself.  So now we have to undo it just to make sure that
       // even if the descriptor is referenced somewhere else we have have returned it to
       // its correct state.  I guess we could avoid the fixup if the descriptor's reference
       // count implied it had no additional references but this is more elegant.
          X.Array_Descriptor.Array_Domain.Base[Axis] =- X.Array_Descriptor.Array_Domain.Stride[Axis];

       // Now we have to delete the input since it was a temporary 
       // (this is part of the temporary management that A++ does)
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          X.decrementReferenceCount();
          if (X.getReferenceCount() < floatSerialArray::getReferenceCountBase())
               delete &((floatSerialArray &) X);
        }

  // puts ("Returning from floatSerialArray sum along axis!");

  // Mark as a temporary
     Result->Array_Descriptor.Array_Domain.Is_A_Temporary = TRUE;

#if COMPILE_DEBUG_STATEMENTS
  // This is the only test we can do on the input!
     Result->Test_Consistency ("Test Result in sum (const floatSerialArray & X, int Axis)");
#endif

     return *Result;
#endif
   }


#ifndef INTARRAY
floatSerialArray &
atan2 ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of atan2 (floatSerialArray,floatSerialArray) for floatSerialArray class! Lhs:rc=%d Rhs:rc=%d ",
               Lhs.getRawDataReferenceCount(),Rhs.getRawDataReferenceCount());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in atan2");
     Rhs.Test_Consistency ("Test Rhs in atan2");
#endif
 
  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & atan2(floatSerialArray,floatSerialArray)");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & atan2(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs and Rhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement (Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
	       puts ("ERROR: can't mix indirect addressing with 2 arrays and where.");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, 
                    *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray,
                     Rhs, Rhs_SerialArray );
             }

          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

  // New test (8/5/2000)
     APP_ASSERT(Temporary_Array_Set != NULL);
  // Temporary_Array_Set->display("Check to see what sort of communication model was used");

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & atan2(floatSerialArray,floatSerialArray)");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & atan2(floatSerialArray,floatSerialArray)");
        }
#endif

  // Inputs to floatArray::Abstract_Binary_Operator:
  //     1. Temporary_Array_Set is attached to the floatArray temporary returned by Abstract_Binary_Operator
  //     2. Lhs is used to get the Lhs partition information (PARTI parallel descriptor) and array reuse
  //     3. Rhs is used to get the Rhs partition information (PARTI parallel descriptor) in case the Lhs was 
  //        a NULL array (no data and no defined partitioning (i.e. no PARTI parallel descriptor)) and array reuse
  //     4. The floatSerialArray which is to be put into the floatArray temporary returned by Abstract_Binary_Operator
  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, atan2(*Lhs_SerialArray,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, atan2(*Lhs_SerialArray,*Rhs_SerialArray) );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
  // if (Lhs_SerialArray != Return_Value.getSerialArrayPointer())
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & atan2(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator_Non_Commutative ( Lhs , Rhs , MDI_f_Arc_Tan2_Array_ArcTan2_Array, MDI_f_Arc_Tan2_Array_ArcTan2_Array_Accumulate_To_Operand , floatSerialArray::atan2_Function );
#endif
   }



floatSerialArray &
atan2 ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\nInside of atan2 (float,floatSerialArray) for floatSerialArray class! \n");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in atan2");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & atan2(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray *Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...
     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
              (Rhs, Rhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}

        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray     != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & atan2(float,floatSerialArray)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, atan2(x,*Rhs_SerialArray) );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, atan2(x,*Rhs_SerialArray) );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value (before delete macro) in floatSerialArray & atan2(float,floatSerialArray)");
        }
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & atan2(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
  // This function can be either Abstract_Binary_Operator or Abstract_Binary_Operator_Non_Commutative
     return floatSerialArray::Abstract_Binary_Operator_Non_Commutative ( Rhs , x ,
               MDI_f_Arc_Tan2_Scalar_ArcTan2_Array,
               MDI_f_Arc_Tan2_Scalar_ArcTan2_Array_Accumulate_To_Operand , floatSerialArray::Scalar_atan2_Function );
#endif
   }



floatSerialArray &
atan2 ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("Inside of atan2 (floatSerialArray,float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in atan2");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts 
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & atan2(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
  // Pointers to views of Lhs serial arrays which allow a conformable operation
     floatSerialArray *Lhs_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE)
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Lhs, Lhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & atan2(floatSerialArray,float)");
        }
#endif

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, atan2(*Lhs_SerialArray,x) );
#if defined(MEMORY_LEAK_TEST)
     puts ("Can't do MEMORY_LEAK_TEST in floatSerialArray & atan2 ( const floatSerialArray & Lhs , float x )");
#endif
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Lhs_SerialArray, atan2(*Lhs_SerialArray,x) );

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray;
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & atan2(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x ,
               MDI_f_Arc_Tan2_Array_ArcTan2_Scalar,
               MDI_f_Arc_Tan2_Array_ArcTan2_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_atan2_Function );
#endif
   }

#endif

#ifdef INTARRAY
floatSerialArray &
operator& ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
        {
          printf ("\n\n\n### Inside of operator& (floatSerialArray,floatSerialArray) for floatSerialArray class: (id=%d) = (id=%d) \n",
               Lhs.Array_ID(),Rhs.Array_ID());
        }

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator&");
     Rhs.Test_Consistency ("Test Rhs in operator&");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs.isTemporary() = %s \n",(Lhs.isTemporary()) ? "TRUE" : "FALSE");
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator&(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs.isTemporary() = %s \n",(Rhs.isTemporary()) ? "TRUE" : "FALSE");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator&(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;
     floatSerialArray* Rhs_SerialArray = NULL;

     intSerialArray* Mask_SerialArray = NULL;
     intSerialArray* Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ( (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
               (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) )
             {
               printf ("Sorry, not implemented: can't mix indirect addressing using where statements and two array (binary) operators!\n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
                  (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator&(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs_SerialArray->isTemporary() = %s \n",(Rhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & operator&(floatSerialArray,floatSerialArray)");
        }
#endif

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, *Lhs_SerialArray & *Rhs_SerialArray );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator 
	( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray & *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator&(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , Rhs , 
               MDI_f_BIT_AND_Array_BitwiseAND_Array,
               MDI_f_BIT_AND_Array_BitwiseAND_Array_Accumulate_To_Operand , floatSerialArray::BitwiseAND );
#endif
   }

floatSerialArray &
operator& ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\n### Inside of operator& (floatSerialArray,float) for floatSerialArray class: (id=%d) = scalar \n",Lhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator&");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator&(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
               APP_ASSERT(Lhs_SerialArray != NULL);
            // Lhs_SerialArray->displayReferenceCounts("AFTER PCE: *Lhs_SerialArray in floatSerialArray & operator&(floatSerialArray,float)");
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator&(floatSerialArray,float)");
        }
#endif

  // (11/27/2000) Added error checking (will not work with indirect addessing later!!!)
     APP_ASSERT(Temporary_Array_Set != NULL);

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator(Temporary_Array_Set,Lhs,Lhs_SerialArray,*Lhs_SerialArray & x);
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in in floatSerialArray & operator&(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x , 
               MDI_f_BIT_AND_Array_BitwiseAND_Scalar,
               MDI_f_BIT_AND_Array_BitwiseAND_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_BitwiseAND );
#endif
   }

floatSerialArray &
operator& ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator& (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator&");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator&(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = 
	      floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL) Temporary_Array_Set =
	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x & *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator&(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Rhs , x , 
               MDI_f_BIT_AND_Scalar_BitwiseAND_Array,
               MDI_f_BIT_AND_Scalar_BitwiseAND_Array_Accumulate_To_Operand , floatSerialArray::Scalar_BitwiseAND );
#endif
   }

floatSerialArray &
floatSerialArray::operator&= ( float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator&= (float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator&=");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator&=(float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( *this , This_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( *this , This_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, This_SerialArray, *This_SerialArray &= x );
     // ... don't need to use macro because Return_Value won't be Mask ...
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;

#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , x ,
        MDI_f_BIT_AND_Array_BitwiseAND_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_BitwiseAND_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator&=(float)");
        }
#endif

     return *this;
   }

#endif

#ifdef INTARRAY
floatSerialArray &
operator| ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
        {
          printf ("\n\n\n### Inside of operator| (floatSerialArray,floatSerialArray) for floatSerialArray class: (id=%d) = (id=%d) \n",
               Lhs.Array_ID(),Rhs.Array_ID());
        }

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator|");
     Rhs.Test_Consistency ("Test Rhs in operator|");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs.isTemporary() = %s \n",(Lhs.isTemporary()) ? "TRUE" : "FALSE");
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator|(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs.isTemporary() = %s \n",(Rhs.isTemporary()) ? "TRUE" : "FALSE");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator|(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;
     floatSerialArray* Rhs_SerialArray = NULL;

     intSerialArray* Mask_SerialArray = NULL;
     intSerialArray* Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ( (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
               (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) )
             {
               printf ("Sorry, not implemented: can't mix indirect addressing using where statements and two array (binary) operators!\n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
                  (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator|(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs_SerialArray->isTemporary() = %s \n",(Rhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & operator|(floatSerialArray,floatSerialArray)");
        }
#endif

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, *Lhs_SerialArray | *Rhs_SerialArray );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator 
	( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray | *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator|(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , Rhs , 
               MDI_f_BIT_OR_Array_BitwiseOR_Array,
               MDI_f_BIT_OR_Array_BitwiseOR_Array_Accumulate_To_Operand , floatSerialArray::BitwiseOR );
#endif
   }

floatSerialArray &
operator| ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\n### Inside of operator| (floatSerialArray,float) for floatSerialArray class: (id=%d) = scalar \n",Lhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator|");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator|(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
               APP_ASSERT(Lhs_SerialArray != NULL);
            // Lhs_SerialArray->displayReferenceCounts("AFTER PCE: *Lhs_SerialArray in floatSerialArray & operator|(floatSerialArray,float)");
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator|(floatSerialArray,float)");
        }
#endif

  // (11/27/2000) Added error checking (will not work with indirect addessing later!!!)
     APP_ASSERT(Temporary_Array_Set != NULL);

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator(Temporary_Array_Set,Lhs,Lhs_SerialArray,*Lhs_SerialArray | x);
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in in floatSerialArray & operator|(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x , 
               MDI_f_BIT_OR_Array_BitwiseOR_Scalar,
               MDI_f_BIT_OR_Array_BitwiseOR_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_BitwiseOR );
#endif
   }

floatSerialArray &
operator| ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator| (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator|");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator|(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = 
	      floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL) Temporary_Array_Set =
	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x | *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator|(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Rhs , x , 
               MDI_f_BIT_OR_Scalar_BitwiseOR_Array,
               MDI_f_BIT_OR_Scalar_BitwiseOR_Array_Accumulate_To_Operand , floatSerialArray::Scalar_BitwiseOR );
#endif
   }

floatSerialArray &
floatSerialArray::operator|= ( float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator|= (float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator|=");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator|=(float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( *this , This_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( *this , This_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, This_SerialArray, *This_SerialArray |= x );
     // ... don't need to use macro because Return_Value won't be Mask ...
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;

#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , x ,
        MDI_f_BIT_OR_Array_BitwiseOR_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_BitwiseOR_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator|=(float)");
        }
#endif

     return *this;
   }

#endif

#ifdef INTARRAY
floatSerialArray &
operator^ ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
        {
          printf ("\n\n\n### Inside of operator^ (floatSerialArray,floatSerialArray) for floatSerialArray class: (id=%d) = (id=%d) \n",
               Lhs.Array_ID(),Rhs.Array_ID());
        }

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator^");
     Rhs.Test_Consistency ("Test Rhs in operator^");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs.isTemporary() = %s \n",(Lhs.isTemporary()) ? "TRUE" : "FALSE");
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator^(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs.isTemporary() = %s \n",(Rhs.isTemporary()) ? "TRUE" : "FALSE");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator^(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;
     floatSerialArray* Rhs_SerialArray = NULL;

     intSerialArray* Mask_SerialArray = NULL;
     intSerialArray* Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ( (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
               (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) )
             {
               printf ("Sorry, not implemented: can't mix indirect addressing using where statements and two array (binary) operators!\n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
                  (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator^(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs_SerialArray->isTemporary() = %s \n",(Rhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & operator^(floatSerialArray,floatSerialArray)");
        }
#endif

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, *Lhs_SerialArray ^ *Rhs_SerialArray );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator 
	( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray ^ *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator^(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , Rhs , 
               MDI_f_BIT_XOR_Array_BitwiseXOR_Array,
               MDI_f_BIT_XOR_Array_BitwiseXOR_Array_Accumulate_To_Operand , floatSerialArray::BitwiseXOR );
#endif
   }

floatSerialArray &
operator^ ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\n### Inside of operator^ (floatSerialArray,float) for floatSerialArray class: (id=%d) = scalar \n",Lhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator^");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator^(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
               APP_ASSERT(Lhs_SerialArray != NULL);
            // Lhs_SerialArray->displayReferenceCounts("AFTER PCE: *Lhs_SerialArray in floatSerialArray & operator^(floatSerialArray,float)");
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator^(floatSerialArray,float)");
        }
#endif

  // (11/27/2000) Added error checking (will not work with indirect addessing later!!!)
     APP_ASSERT(Temporary_Array_Set != NULL);

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator(Temporary_Array_Set,Lhs,Lhs_SerialArray,*Lhs_SerialArray ^ x);
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in in floatSerialArray & operator^(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x , 
               MDI_f_BIT_XOR_Array_BitwiseXOR_Scalar,
               MDI_f_BIT_XOR_Array_BitwiseXOR_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_BitwiseXOR );
#endif
   }

floatSerialArray &
operator^ ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator^ (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator^");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator^(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = 
	      floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL) Temporary_Array_Set =
	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x ^ *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator^(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Rhs , x , 
               MDI_f_BIT_XOR_Scalar_BitwiseXOR_Array,
               MDI_f_BIT_XOR_Scalar_BitwiseXOR_Array_Accumulate_To_Operand , floatSerialArray::Scalar_BitwiseXOR );
#endif
   }

floatSerialArray &
floatSerialArray::operator^= ( float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of floatSerialArray::operator^= (float) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operator^=");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator^=(float)");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( *this , This_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( *this , This_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );

#if !defined(MEMORY_LEAK_TEST)
     floatArray::Abstract_Modification_Operator ( Temporary_Array_Set, *this, This_SerialArray, *This_SerialArray ^= x );
     // ... don't need to use macro because Return_Value won't be Mask ...
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;

#else
     floatSerialArray::Abstract_Operator_Operation_Equals ( *this , x ,
        MDI_f_BIT_XOR_Array_BitwiseXOR_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_BitwiseXOR_Equals );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS (return value) in floatSerialArray & floatSerialArray::operator^=(float)");
        }
#endif

     return *this;
   }

#endif

#ifdef INTARRAY
/* There is no <<= operator and so the << must be handled as a special case -- skip it for now */
floatSerialArray &
operator<< ( const floatSerialArray & Lhs , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
        {
          printf ("\n\n\n### Inside of operator<< (floatSerialArray,floatSerialArray) for floatSerialArray class: (id=%d) = (id=%d) \n",
               Lhs.Array_ID(),Rhs.Array_ID());
        }

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator<<");
     Rhs.Test_Consistency ("Test Rhs in operator<<");
#endif

  // Are the arrays the same size (otherwise issue error message and stop).
     if (Index::Index_Bounds_Checking)
          Lhs.Test_Conformability (Rhs);

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs.isTemporary() = %s \n",(Lhs.isTemporary()) ? "TRUE" : "FALSE");
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator<<(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs.isTemporary() = %s \n",(Rhs.isTemporary()) ? "TRUE" : "FALSE");
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator<<(floatSerialArray,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;
     floatSerialArray* Rhs_SerialArray = NULL;

     intSerialArray* Mask_SerialArray = NULL;
     intSerialArray* Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if ((Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
	      (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE))
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray, Rhs, Rhs_SerialArray );
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if ( (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) ||
               (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) )
             {
               printf ("Sorry, not implemented: can't mix indirect addressing using where statements and two array (binary) operators!\n");
               APP_ABORT();
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement
                  (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray, Rhs, Rhs_SerialArray );
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator<<(floatSerialArray,floatSerialArray)");
          printf ("floatSerialArray: Rhs_SerialArray->isTemporary() = %s \n",(Rhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Rhs_SerialArray->displayReferenceCounts("Rhs_SerialArray in floatSerialArray & operator<<(floatSerialArray,floatSerialArray)");
        }
#endif

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();
     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );
     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, Lhs, Rhs, *Lhs_SerialArray << *Rhs_SerialArray );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator 
	( Temporary_Array_Set, Lhs, Rhs, Lhs_SerialArray, Rhs_SerialArray, *Lhs_SerialArray << *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator<<(floatSerialArray,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , Rhs , 
               MDI_f_BIT_LSHIFT_Array_BitwiseLShift_Array,
               MDI_f_BIT_LSHIFT_Array_BitwiseLShift_Array_Accumulate_To_Operand , floatSerialArray::BitwiseLShift );
#endif
   }

floatSerialArray &
operator<< ( const floatSerialArray & Lhs , float x )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          printf ("\n\n\n### Inside of operator<< (floatSerialArray,float) for floatSerialArray class: (id=%d) = scalar \n",Lhs.Array_ID());

  // This is the only test we can do on the input!
     Lhs.Test_Consistency ("Test Lhs in operator<<");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Lhs.displayReferenceCounts("Lhs in floatSerialArray & operator<<(floatSerialArray,float)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Lhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
        {
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( Lhs, Lhs_SerialArray );
               APP_ASSERT(Lhs_SerialArray != NULL);
            // Lhs_SerialArray->displayReferenceCounts("AFTER PCE: *Lhs_SerialArray in floatSerialArray & operator<<(floatSerialArray,float)");
             }
        }
       else
        {
          Old_Mask_SerialArray = Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
          if (Lhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
             {
               Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
            else
             {
               Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
                    (Lhs, Lhs_SerialArray, *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
             }
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Mask_SerialArray;
        }

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          printf ("floatSerialArray: Lhs_SerialArray->isTemporary() = %s \n",(Lhs_SerialArray->isTemporary()) ? "TRUE" : "FALSE");
          Lhs_SerialArray->displayReferenceCounts("Lhs_SerialArray in floatSerialArray & operator<<(floatSerialArray,float)");
        }
#endif

  // (11/27/2000) Added error checking (will not work with indirect addessing later!!!)
     APP_ASSERT(Temporary_Array_Set != NULL);

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set = new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Lhs_SerialArray != NULL);

     bool lhsIsTemporary = Lhs_SerialArray->isTemporary();

     APP_ASSERT ( (lhsIsTemporary == TRUE) || (lhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Lhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator(Temporary_Array_Set,Lhs,Lhs_SerialArray,*Lhs_SerialArray << x);
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (lhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Lhs_SerialArray->getReferenceCount() = %d \n",
       //      Lhs_SerialArray->getReferenceCount());

       // Must delete the Lhs_SerialArray if it was taken directly from the Lhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Lhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Lhs_SerialArray->decrementReferenceCount();
          if (Lhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Lhs_SerialArray;
             }
          Lhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
          *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in in floatSerialArray & operator<<(floatSerialArray,float)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Lhs , x , 
               MDI_f_BIT_LSHIFT_Array_BitwiseLShift_Scalar,
               MDI_f_BIT_LSHIFT_Array_BitwiseLShift_Scalar_Accumulate_To_Operand , floatSerialArray::Scalar_BitwiseLShift );
#endif
   }

floatSerialArray &
operator<< ( float x , const floatSerialArray & Rhs )
   {
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of operator<< (float,floatSerialArray) for floatSerialArray class!");

  // This is the only test we can do on the input!
     Rhs.Test_Consistency ("Test Rhs in operator<<");
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Rhs.displayReferenceCounts("Rhs in floatSerialArray & operator<<(float,floatSerialArray)");
        }
#endif

#if defined(PPP)
     floatSerialArray* Rhs_SerialArray = NULL;

  // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray     = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL;
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      ( Rhs, Rhs_SerialArray );
        }
	else
	{
           Temporary_Array_Set = 
	      floatArray::Parallel_Conformability_Enforcement ( Rhs, Rhs_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Rhs.Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (Rhs, Rhs_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }
     if (Temporary_Array_Set == NULL) Temporary_Array_Set =
	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(Rhs_SerialArray != NULL);

     bool rhsIsTemporary = Rhs_SerialArray->isTemporary();

     APP_ASSERT ( (rhsIsTemporary == TRUE) || (rhsIsTemporary == FALSE) );

#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = Rhs;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, Rhs, Rhs_SerialArray, x << *Rhs_SerialArray );
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (rhsIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): Rhs_SerialArray->getReferenceCount() = %d \n",
       //      Rhs_SerialArray->getReferenceCount());

       // Must delete the Rhs_SerialArray if it was taken directly from the Rhs array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (Rhs_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          Rhs_SerialArray->decrementReferenceCount();
          if (Rhs_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete Rhs_SerialArray;
             }
          Rhs_SerialArray = NULL;

        }

  // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & operator<<(float,floatSerialArray)");
        }
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Binary_Operator ( Rhs , x , 
               MDI_f_BIT_LSHIFT_Scalar_BitwiseLShift_Array,
               MDI_f_BIT_LSHIFT_Scalar_BitwiseLShift_Array_Accumulate_To_Operand , floatSerialArray::Scalar_BitwiseLShift );
#endif
   }


floatSerialArray &
floatSerialArray::operator~ () const
   { 
#if COMPILE_DEBUG_STATEMENTS
     if (APP_DEBUG > 0)
          puts ("Inside of unary minus operator operator~ for floatSerialArray class!");

  // This is the only test we can do on the input!
     Test_Consistency ("Test *this in floatSerialArray::operatoroperator~");
#endif
 
#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          displayReferenceCounts("THIS in floatSerialArray & floatSerialArray::operator~()");
        }
#endif

#if defined(PPP)
     floatSerialArray *This_SerialArray = NULL;

     // ... bug fix (4/10/97, kdb) must make serial where mask conformable ...

     intSerialArray *Mask_SerialArray = NULL;
     intSerialArray *Old_Mask_SerialArray = NULL;

     Array_Conformability_Info_Type *Temporary_Array_Set = NULL; 
     if (Where_Statement_Support::Where_Statement_Mask == NULL)
     {
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
	   Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement ( *this , This_SerialArray );
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement ( *this , This_SerialArray );
	}
     }
     else
     {
	Old_Mask_SerialArray = 
           Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointer();
        if (Array_Descriptor.Array_Domain.Uses_Indirect_Addressing == TRUE) 
        {
           Temporary_Array_Set = floatArray::Parallel_Indirect_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
        }
	else
	{
           Temporary_Array_Set = floatArray::Parallel_Conformability_Enforcement 
	      (*this, This_SerialArray, 
               *Where_Statement_Support::Where_Statement_Mask, Mask_SerialArray);
	}
        *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() =
	   Mask_SerialArray;
     }

     if (Temporary_Array_Set == NULL)
          Temporary_Array_Set =	new Array_Conformability_Info_Type();

     APP_ASSERT(Temporary_Array_Set != NULL);
     APP_ASSERT(This_SerialArray != NULL);

     bool thisIsTemporary = This_SerialArray->isTemporary();

     APP_ASSERT ( (thisIsTemporary == TRUE) || (thisIsTemporary == FALSE) );

  // return floatArray::Abstract_Operator ( Temporary_Array_Set, *this, This_SerialArray->operator~() );
#if defined(MEMORY_LEAK_TEST)
     floatArray & Return_Value = *this;
#else
     floatArray & Return_Value = floatArray::Abstract_Operator ( Temporary_Array_Set, *this, This_SerialArray, This_SerialArray->operator~() );
#endif

#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value (before delete This_SerialArray) in floatSerialArray & floatSerialArray::operator~()");
        }

  // This is the only test we can do on the output!
     Return_Value.Test_Consistency ("Test Return_Value (before delete This_SerialArray) in floatSerialArray::operatoroperator~");
#endif

  // Check for reuse of serialArray object in return value (do not delete it if it was reused)
     if (thisIsTemporary == FALSE)
        {
          // Only delete the serial array data when the Overlap update model is used
       // printf ("In Macro Delete SerialArray (before decrement): This_SerialArray->getReferenceCount() = %d \n",
       //      This_SerialArray->getReferenceCount());

       // Must delete the This_SerialArray if it was taken directly from the This array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          APP_ASSERT (This_SerialArray->getReferenceCount() >= intSerialArray::getReferenceCountBase());
          This_SerialArray->decrementReferenceCount();
          if (This_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete This_SerialArray;
             }
          This_SerialArray = NULL;

        }

     // ... don't need to use macro because Return_Value won't be Mask ...
     if (Where_Statement_Support::Where_Statement_Mask != NULL)
        {
         *Where_Statement_Support::Where_Statement_Mask->getSerialArrayPointerLoc() = Old_Mask_SerialArray; 
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          Mask_SerialArray->decrementReferenceCount();
          if (Mask_SerialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
               delete Mask_SerialArray;
          Mask_SerialArray = NULL;
        }

     // Delete the Temporary_Array_Set
  // printf ("In MACRO in operator.C: Temporary_Array_Set->getReferenceCount() = %d \n",Temporary_Array_Set->getReferenceCount());
     APP_ASSERT (Temporary_Array_Set->getReferenceCount() >= Array_Conformability_Info_Type::getReferenceCountBase());
     Temporary_Array_Set->decrementReferenceCount();
     if (Temporary_Array_Set->getReferenceCount() < Array_Conformability_Info_Type::getReferenceCountBase())
        {
       // printf ("COMMENTED OUT CALL TO DELETE: Deleting the Temporary_Array_Set in Macro Delete Temporary_Array_Set \n");
          delete Temporary_Array_Set;
        }
     Temporary_Array_Set = NULL;


#if COMPILE_DEBUG_STATEMENTS
     if (Diagnostic_Manager::getReferenceCountingReport() > 0)
        {
       // This mechanism outputs reports which allow us to trace the reference counts
          Return_Value.displayReferenceCounts("Return_Value in floatSerialArray & floatSerialArray::operator~()");
        }

  // This is the only test we can do on the output!
     Return_Value.Test_Consistency ("Test Return_Value in floatSerialArray::operatoroperator~");
#endif

     return Return_Value;
#else
     return floatSerialArray::Abstract_Unary_Operator ( *this ,
                   MDI_f_BIT_COMPLEMENT_Array ,
                   MDI_f_BIT_COMPLEMENT_Array_Accumulate_To_Operand , floatSerialArray::Unary_Minus );
#endif
   } 

#endif



















/*
// This code would simplify the macro to a function call
define(Macro_Delete_X_SerialArray,    Delete_SerialArray(X,X_SerialArray,Temporary_Array_Set);)
define(Macro_Delete_This_SerialArray, Delete_SerialArray((*this),This_SerialArray,Temporary_Array_Set);)
define(Macro_Delete_Lhs_SerialArray,  Delete_SerialArray(Lhs,Lhs_SerialArray,Temporary_Array_Set);)
define(Macro_Delete_Rhs_SerialArray,  Delete_SerialArray(Rhs,Rhs_SerialArray,Temporary_Array_Set);)

void
Delete_PCE_SerialArray (
     const $4Array & parallelArray,
     $4SerialArray* serialArray,
     const Array_Conformability_Info_Type *Temporary_Array_Set )
   {
     APP_ASSERT(Temporary_Array_Set != NULL);
     if (Temporary_Array_Set->Full_VSG_Update_Required == FALSE || TRUE)
        {
       // Only delete the serial array data when the Overlap update model is used

       // printf ("In Macro Delete SerialArray (before decrement): $1_SerialArray->getReferenceCount() = %d \n",
       //      $1_SerialArray->getReferenceCount());

       // Handle case where PADRE is used
#if defined(USE_PADRE)
       // when using PADRE we have to clear the use of the SerialArray_Domain before
       // deleting the SerialArray object.
          parallelArray.setLocalDomainInPADRE_Descriptor(NULL);
#endif

       // Can't reference Return_Value in all functions
       // APP_ASSERT ($1_SerialArray != NULL);
       // APP_ASSERT (Return_Value.Array_Descriptor.SerialArray != NULL);
       // APP_ASSERT (Return_Value.Array_Descriptor.SerialArray->Array_ID() != $1_SerialArray->Array_ID());

       // Must delete the $1_SerialArray if it was taken directly from the $1 array!
       // Added conventional mechanism for reference counting control
       // operator delete no longer decriments the referenceCount.
          serialArray->decrementReferenceCount();
          if (serialArray->getReferenceCount() < intSerialArray::getReferenceCountBase())
             {
            // printf ("Deleting the serial array in Macro Delete SerialArray \n");
               delete serialArray;
             }
          serialArray = NULL;
        }
   }
*/




 

 





 

 





















 









































